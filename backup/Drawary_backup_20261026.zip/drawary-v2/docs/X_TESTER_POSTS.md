# X 테스터 모집 글

비공개 테스트 참여자를 X에서 모집할 때 쓰는 글이에요. 이메일은 DM으로 받아요(공개 답글로 받지 않아요).

- 이미지는 `release/store/KR|EN|JP/feature_graphic_1024x500.png`를 그대로 써요.
- 먼저 개인 계정에 올려 반응을 보고, 공식 계정에는 그다음에 올려요.
- 글자 수는 올리기 전에 X에서 한 번 더 확인해요 (한국어, 일본어는 글자당 2로 셈해요).

## 올리기 전에

1. 계정의 DM이 열려 있어야 이메일을 받을 수 있어요. (팔로워에게만 열어 두었다면 글에 "팔로우하고 DM 주세요"를 한 줄 넣어요.)
2. 받은 이메일은 Play Console 비공개 테스트의 **테스터 목록**에 넣고, 참여 링크를 DM으로 보내요.
3. 등록이 끝난 이메일은 DM 기록에서 지워요. 글에 "바로 지운다"고 썼으니 지켜요.
4. 이메일은 Play 스토어에서 쓰는 **구글 계정**이어야 해요.
5. 참여 링크가 열리는지 본인 계정으로 한 번 확인해요.

---

## 개인 계정

### 한국어

본문
```
책, 영화, 화장품 같은 모으는 것들을 서랍에 담아서 기록하는 앱을 만들었어요. 지금 안드로이드에서 비공개 테스트 중인데, 써 보고 불편한 점 한두 개만 말해 줄 분 계실까요? Play 스토어에서 쓰는 구글 계정 이메일을 DM으로 보내 주시면 등록해 드릴게요.
```
답글
```
이메일은 테스터로 등록할 때만 쓰고 바로 지울게요. 댓글 말고 DM으로 부탁드려요.
등록되면 참여 링크를 보내 드릴게요. 링크에서 참여한 다음에 Play 스토어에서 받으시면 돼요.
아, 프리미엄 결제 화면은 누르지 말아 주세요. 테스트 중에도 실제로 결제될 수 있어요.
```

### 日本語

本文
```
本や映画、コスメみたいに集めているものを「ひきだし」に入れて記録するアプリを作りました。今Androidでクローズドテスト中です。使ってみて、気になったところを一つ二つ教えてくれる方いませんか？Playストアで使っているGoogleアカウントのメールをDMで送ってもらえれば、登録します。
```
返信
```
メールは登録のときだけ使って、すぐ消します。リプライじゃなくてDMでお願いします。
登録できたら参加リンクを送るので、リンクから参加してPlayストアで入れてください。
あと、プレミアムの購入画面は押さないでください。テスト中でも本当に課金されることがあります。
```

### English

Post
```
I made an app for keeping track of the stuff you collect (books, movies, cosmetics, that kind of thing) in little drawers. It's in closed testing on Android right now. If you'd try it and tell me a thing or two that bugged you, DM me the email of the Google account you use on Play and I'll add you.
```
Reply
```
I only use the email to add you as a tester, then I delete it. DM please, not a public reply.
Once you're in I'll send you the join link. Join through it, then install from the Play Store.
Oh, and please don't tap the Premium purchase screen. Even in testing it can really charge you.
```

---

## 공식 계정 (Howling Creative Studio)

### 한국어

본문
```
Howling Creative Studio에서 "나만의 서랍장"이라는 앱을 만들었어요. 책, 영화, 화장품, 식물처럼 모으는 것들을 서랍에 담아서 기록하는 앱이에요.

지금 안드로이드에서 비공개 테스트를 하고 있어요. 써 보시고 불편한 점을 한두 가지만 알려 주실 분을 찾고 있어요. Play 스토어에서 쓰시는 구글 계정 이메일을 DM으로 보내 주시면 테스터로 등록해 드릴게요.
```
답글
```
보내 주신 이메일은 테스터 등록에만 쓰고, 등록이 끝나면 바로 지워요. 공개 답글 말고 DM으로 보내 주세요.
등록이 되면 참여 링크를 DM으로 보내 드려요. 링크에서 참여하신 뒤 Play 스토어에서 설치하시면 돼요.
프리미엄(결제) 화면은 눌러 보지 말아 주세요. 테스트 중에도 실제로 결제될 수 있어요.
```

### 日本語

本文
```
Howling Creative Studioで「ひきだし帳」というアプリを作りました。本、映画、コスメ、植物など、集めているものをひきだしに入れて記録するアプリです。

現在Androidでクローズドテストを行っています。使ってみて、気になった点を一つ二つ教えてくださる方を探しています。Playストアで使っているGoogleアカウントのメールアドレスをDMでお送りいただければ、テスターとして登録します。
```
返信
```
お送りいただいたメールアドレスはテスター登録にのみ使用し、登録後すぐに削除します。公開の返信ではなく、DMでお送りください。
登録できましたら、参加リンクをDMでお送りします。リンクから参加後、Playストアでインストールしてください。
プレミアム（購入）画面は押さないでください。テスト中でも実際に課金されることがあります。
```

### English

Post
```
We at Howling Creative Studio made an app called Drawary. It lets you keep track of the things you collect (books, movies, cosmetics, plants) in drawers.

It's in closed testing on Android right now, and we're looking for a few people to try it and tell us one or two things that felt off. DM us the email of the Google account you use on Play and we'll add you as a tester.
```
Reply
```
We only use your email to add you as a tester, and delete it afterwards. Please send it by DM, not in a public reply.
Once you're added, we'll DM you the join link. Join through it, then install from the Play Store.
Please don't tap the Premium purchase screen. Even in testing it can really charge you.
```
