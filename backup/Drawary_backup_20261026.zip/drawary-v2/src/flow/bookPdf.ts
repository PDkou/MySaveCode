import { PAGE_H, PAGE_W, MARGIN, assemblePdf, layoutTable, wrapText, type Measure } from './tablePdf';
import { t } from '../i18n';

/**
 * "도감 PDF": a drawer made into something to look at and share. A cover in the drawer's colour, the items that were rated highest (or
 * the newest ones) with their photos, then every item in a list with a small photo. Drawn on canvas pages like the table PDF
 * (tablePdf.ts) and packed into the same kind of file. The layout is in plain functions; the drawing needs a canvas.
 */

export interface BookItem {
  id: string;
  /** What the first column shows (the item's name). */
  title: string;
  /** 1-5, when the drawer has a rating field and this item has a rating. */
  rating: number | null;
  /** The other chosen columns as label/text. */
  fields: { label: string; text: string; isRating?: boolean }[];
  /** Newest first is the order given. */
  photo: Blob | null;
}

export interface BookOptions {
  drawerName: string;
  /** Soft tint of the drawer (its card colour). */
  tint: string;
  iconUrl: string;
  fallbackIconUrl: string;
  items: BookItem[];
  /** Whether photos are drawn at all. */
  withPhotos: boolean;
  createdAt: Date;
  locale: string;
  /** Called before each page is drawn, so the waiting screen can show where it is. */
  onProgress?: (page: number, total: number) => void;
}

const SCALE = 1.5;
const FONT = "'Noto Sans CJK KR','Noto Sans KR','Noto Sans JP','Noto Sans CJK JP',sans-serif";
const INK = '#2f2a55';
const SOFT = '#7c7596';
const PAPER = '#fffaf2';
const LIST_INSET = 78;
const LIST_TITLE_BLOCK = 104;
const PICKS = 3;
const TEXT = 15;
const LINE_H = 21;

const stars = (n: number): string => '★'.repeat(n) + '☆'.repeat(5 - n);

/** The items for the "favourites" page: the highest rated (ties: newer first), or the newest when nothing is rated. */
export function pickFavourites(items: readonly BookItem[]): { picks: BookItem[]; byRating: boolean } {
  const rated = items.filter((i) => i.rating !== null);
  if (rated.length > 0) {
    const order = new Map(items.map((i, index) => [i.id, index]));
    const sorted = [...rated].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0) || (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0));
    return { picks: sorted.slice(0, PICKS), byRating: true };
  }
  return { picks: items.slice(0, PICKS), byRating: false };
}

export function averageRating(items: readonly BookItem[]): number | null {
  const rated = items.filter((i) => i.rating !== null);
  if (rated.length === 0) return null;
  return Math.round((rated.reduce((sum, i) => sum + (i.rating ?? 0), 0) / rated.length) * 10) / 10;
}

const loadImage = (url: string): Promise<HTMLImageElement | null> => new Promise((resolve) => {
  const img = new Image();
  img.onload = () => resolve(img);
  img.onerror = () => resolve(null);
  img.src = url;
});

/** Draws `source` into the box so that it fills it (cropping the overflow), with rounded corners. */
function drawCover(ctx: CanvasRenderingContext2D, source: CanvasImageSource, sw: number, sh: number, x: number, y: number, w: number, h: number, radius: number): void {
  ctx.save();
  roundRect(ctx, x, y, w, h, radius);
  ctx.clip();
  const k = Math.max(w / sw, h / sh);
  const dw = sw * k;
  const dh = sh * k;
  ctx.drawImage(source, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  ctx.restore();
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

async function decode(blob: Blob): Promise<{ source: CanvasImageSource; w: number; h: number; close: () => void } | null> {
  try {
    const bitmap = await createImageBitmap(blob);
    return { source: bitmap, w: bitmap.width, h: bitmap.height, close: () => bitmap.close() };
  } catch { return null; }
}

export async function renderBookPdf(o: BookOptions): Promise<Blob> {
  try { await document.fonts?.ready; } catch { /* draw with what there is */ }
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(PAGE_W * SCALE);
  canvas.height = Math.round(PAGE_H * SCALE);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('canvas');
  const font = (bold: boolean, px: number) => `${bold ? '700' : '400'} ${px}px ${FONT}`;
  const measure = (px: number): Measure => (text, bold) => { ctx.font = font(bold, px); return ctx.measureText(text).width; };

  const [icon, fallbackIcon, mascot, brand] = await Promise.all([
    loadImage(o.iconUrl), loadImage(o.fallbackIconUrl), loadImage('/assets/mascot/mascot_happy.webp'), loadImage('/assets/brand/brand_symbol_flower_small.webp'),
  ]);
  const appName = t('나만의 서랍장');
  const { picks, byRating } = pickFavourites(o.items);
  const average = averageRating(o.items);
  const bookTitle = t('나의 {name} 도감', { name: o.drawerName });

  // ---- the list's layout decides how many pages there are
  const labels = [t('이름'), ...(o.items[0]?.fields.map((f) => f.label) ?? [])];
  const texts = o.items.map((i) => [i.title, ...i.fields.map((f) => f.text)]);
  const list = layoutTable(measure(TEXT), labels, texts.length ? texts : [[t('보관품이 없어요.')]], { leftInset: LIST_INSET, minRowH: 68, titleBlock: LIST_TITLE_BLOCK, lineHeight: LINE_H });
  const total = 2 + list.pages.length;

  const jpegs: { jpeg: Uint8Array; w: number; h: number }[] = [];
  const finish = async (): Promise<void> => {
    const blob: Blob | null = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.82));
    if (!blob) throw new Error('jpeg');
    jpegs.push({ jpeg: new Uint8Array(await blob.arrayBuffer()), w: canvas.width, h: canvas.height });
  };
  const begin = (fill: string | CanvasGradient) => {
    ctx.setTransform(SCALE, 0, 0, SCALE, 0, 0);
    ctx.fillStyle = fill;
    ctx.fillRect(0, 0, PAGE_W, PAGE_H);
    ctx.textBaseline = 'top';
    ctx.textAlign = 'left';
  };
  const footer = (page: number) => {
    ctx.fillStyle = '#a79fb8';
    ctx.font = font(false, 13);
    ctx.textAlign = 'left';
    ctx.fillText(bookTitle, 64, PAGE_H - 40);
    ctx.textAlign = 'right';
    ctx.fillText(`${page} / ${total}`, PAGE_W - 64, PAGE_H - 40);
    ctx.textAlign = 'left';
  };

  // ---- page 1: the cover
  o.onProgress?.(1, total);
  const grad = ctx.createLinearGradient(0, 0, PAGE_W, PAGE_H);
  grad.addColorStop(0, o.tint);
  grad.addColorStop(0.55, '#fff6ee');
  grad.addColorStop(1, '#f1e9ff');
  begin(grad);
  ctx.fillStyle = 'rgba(255,255,255,.55)';
  ctx.beginPath(); ctx.arc(PAGE_W - 40, 60, 210, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(20, PAGE_H - 20, 150, 0, Math.PI * 2); ctx.fill();
  // icon card
  ctx.save();
  ctx.shadowColor = 'rgba(80,60,120,.18)'; ctx.shadowBlur = 30; ctx.shadowOffsetY = 10;
  ctx.fillStyle = '#ffffff'; roundRect(ctx, PAGE_W - 300, 70, 150, 150, 38); ctx.fill();
  ctx.restore();
  const glyph = icon ?? fallbackIcon;
  if (glyph) ctx.drawImage(glyph, PAGE_W - 280, 90, 110, 110);
  // title block
  ctx.fillStyle = SOFT; ctx.font = font(true, 18);
  ctx.fillText(appName, 84, 146);
  let titleSize = 76;
  const fit = (size: number) => wrapText(bookTitle, 560, measure(size), true);
  while (titleSize > 40 && fit(titleSize).length > 2) titleSize -= 4;
  const titleLines = fit(titleSize);
  ctx.fillStyle = INK; ctx.font = font(true, titleSize);
  titleLines.forEach((line, i) => ctx.fillText(line, 84, 178 + i * titleSize * 1.18));
  const afterTitle = 178 + titleLines.length * titleSize * 1.18 + 12;
  ctx.fillStyle = SOFT; ctx.font = font(false, 26);
  ctx.fillText(t('좋아하는 것들을 모아 두었어요'), 84, afterTitle);
  // numbers
  const month = new Intl.DateTimeFormat(o.locale, { year: 'numeric', month: 'long' }).format(o.createdAt);
  const numbers: { big: string; small: string }[] = [{ big: t('{n}개', { n: o.items.length }), small: t('담아 둔 것') }];
  if (average !== null) numbers.push({ big: `★ ${average.toFixed(1)}`, small: t('평균 별점') });
  numbers.push({ big: month, small: t('만든 달') });
  let nx = 84;
  numbers.forEach((n) => {
    ctx.fillStyle = INK; ctx.font = font(true, 38);
    ctx.fillText(n.big, nx, afterTitle + 78);
    const width = ctx.measureText(n.big).width;
    ctx.fillStyle = SOFT; ctx.font = font(false, 17);
    ctx.fillText(n.small, nx, afterTitle + 128);
    nx += Math.max(width, 80) + 44;
  });
  if (mascot) { const mw = 380; ctx.drawImage(mascot, PAGE_W - mw - 70, PAGE_H - (mascot.height * mw) / mascot.width - 36, mw, (mascot.height * mw) / mascot.width); }
  if (brand) ctx.drawImage(brand, 84, PAGE_H - 78, 34, 34);
  ctx.fillStyle = SOFT; ctx.font = font(false, 16);
  ctx.fillText(t('{app}로 만들었어요', { app: appName }), brand ? 128 : 84, PAGE_H - 70);
  await finish();

  // ---- page 2: favourites
  o.onProgress?.(2, total);
  begin(PAPER);
  ctx.fillStyle = INK; ctx.font = font(true, 38);
  ctx.fillText(byRating ? t('가장 마음에 든 것들') : t('최근에 담은 것들'), 64, 52);
  ctx.fillStyle = SOFT; ctx.font = font(false, 19);
  ctx.fillText(byRating ? t('별점이 높은 순서대로 모았어요.') : t('가장 나중에 담은 순서대로 모았어요.'), 64, 106);
  const cardW = (PAGE_W - 128 - 2 * 22) / 3;
  const cardTop = 158;
  const photoH = 340;
  for (let i = 0; i < picks.length; i += 1) {
    const item = picks[i];
    const x = 64 + i * (cardW + 22);
    ctx.save();
    ctx.shadowColor = 'rgba(80,60,120,.14)'; ctx.shadowBlur = 18; ctx.shadowOffsetY = 6;
    ctx.fillStyle = '#ffffff'; roundRect(ctx, x, cardTop, cardW, photoH + 196, 22); ctx.fill();
    ctx.restore();
    ctx.fillStyle = o.tint;
    ctx.save(); roundRect(ctx, x, cardTop, cardW, photoH, 22); ctx.clip(); ctx.fillRect(x, cardTop, cardW, photoH); ctx.restore();
    const decoded = o.withPhotos && item.photo ? await decode(item.photo) : null;
    if (decoded) { drawCover(ctx, decoded.source, decoded.w, decoded.h, x, cardTop, cardW, photoH, 22); decoded.close(); }
    else if (glyph) ctx.drawImage(glyph, x + cardW / 2 - 50, cardTop + photoH / 2 - 50, 100, 100);
    let ty = cardTop + photoH + 20;
    if (item.rating !== null) { ctx.fillStyle = '#e0923a'; ctx.font = font(false, 20); ctx.fillText(stars(item.rating), x + 20, ty); ty += 30; }
    ctx.fillStyle = INK; ctx.font = font(true, 23);
    wrapText(item.title, cardW - 40, measure(23), true).slice(0, 2).forEach((line) => { ctx.fillText(line, x + 20, ty); ty += 30; });
    ty += 4;
    for (const f of item.fields.filter((fl) => fl.text && !fl.isRating).slice(0, 2)) {
      ctx.font = font(false, 15);
      ctx.fillStyle = SOFT;
      const labelText = f.label;
      ctx.fillText(labelText, x + 20, ty);
      const labelW = ctx.measureText(labelText).width + 12;
      ctx.fillStyle = '#4a4566';
      const value = wrapText(f.text, Math.max(40, cardW - 40 - labelW), measure(15), false)[0] ?? '';
      ctx.fillText(value, x + 20 + labelW, ty);
      ty += 24;
    }
  }
  footer(2);
  await finish();

  // ---- the rest: every item
  for (let p = 0; p < list.pages.length; p += 1) {
    o.onProgress?.(3 + p, total);
    begin(PAPER);
    let top = list.otherTop;
    if (p === 0) {
      ctx.fillStyle = INK; ctx.font = font(true, 38);
      ctx.fillText(t('모아 둔 것 전부'), 64, 52);
      ctx.fillStyle = SOFT; ctx.font = font(false, 19);
      ctx.fillText(t('{n}개를 최근에 담은 순서로 정리했어요.', { n: o.items.length }), 64, 104);
      top = list.firstTop;
    }
    // header
    ctx.font = font(true, TEXT);
    ctx.fillStyle = SOFT;
    list.header.cells.forEach((cell, c) => cell.forEach((line, i) => ctx.fillText(line, list.colX[c] + 8, top + 6 + i * LINE_H)));
    ctx.strokeStyle = '#e6d9dc'; ctx.lineWidth = 1;
    const lineY = top + list.header.h;
    ctx.beginPath(); ctx.moveTo(MARGIN + 22, lineY + 0.5); ctx.lineTo(PAGE_W - MARGIN - 22, lineY + 0.5); ctx.stroke();
    for (const row of list.pages[p].rows) {
      const index = list.pages.slice(0, p).reduce((n, pg) => n + pg.rows.length, 0) + list.pages[p].rows.indexOf(row);
      const item = o.items[index];
      if (item) {
        const decoded = o.withPhotos && item.photo ? await decode(item.photo) : null;
        const ph = 52;
        const px = MARGIN + 20;
        const py = row.y + (row.h - ph) / 2;
        ctx.fillStyle = o.tint; roundRect(ctx, px, py, ph, ph, 14); ctx.fill();
        if (decoded) { drawCover(ctx, decoded.source, decoded.w, decoded.h, px, py, ph, ph, 14); decoded.close(); }
        else if (glyph) ctx.drawImage(glyph, px + 7, py + 7, ph - 14, ph - 14);
      }
      row.cells.forEach((cell, c) => {
        ctx.fillStyle = c === 0 ? INK : '#4a4566';
        ctx.font = font(c === 0, c === 0 ? TEXT + 1 : TEXT);
        const lines = cell.length;
        const startY = row.y + (row.h - lines * LINE_H) / 2 + 2;
        cell.forEach((line, i) => ctx.fillText(line, list.colX[c] + 8, startY + i * LINE_H));
      });
      ctx.strokeStyle = '#efe3e6';
      ctx.beginPath(); ctx.moveTo(MARGIN + 22, row.y + row.h + 0.5); ctx.lineTo(PAGE_W - MARGIN - 22, row.y + row.h + 0.5); ctx.stroke();
    }
    footer(3 + p);
    await finish();
    await new Promise((resolve) => setTimeout(resolve));
  }
  return new Blob([assemblePdf(jpegs) as BlobPart], { type: 'application/pdf' });
}
