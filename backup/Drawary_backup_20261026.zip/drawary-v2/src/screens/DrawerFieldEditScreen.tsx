import { useState } from 'react';
import { ScreenHeader } from '../components/ScreenHeader';
import './DrawerFieldEditScreen.css';
import type { FieldKind } from '../data/types';
import { FIELD_TYPES } from './NewFieldScreen';
import { t, tl, tx, K } from '../i18n';

// Ported from Drawary_11_FINAL_CONFIRMED_CODE (CONFIRMED.md: 행 전체 탭 →
// 수정 / 손잡이 → 순서 변경 전용 / 숨겨진 스와이프 액션 사용 안 함).
//
// Reconstruction note: the archive's own TSX still implements an OLDER
// swipe-to-reveal interaction for one row ("category") and has no
// onClick on the other rows at all -- directly contradicting both
// CONFIRMED.md and README.md's "탭하면 수정" requirement, and contradicting
// its own paired CSS file, which carries a `/* V2: no hidden swipe
// actions */` comment introducing `.df-row-tap` (a full-row invisible tap
// button), `.df-row-edit-hint` (a per-row "›" hint) and `.df-row.is-editable`
// (a 5-column grid with room for that hint) -- none of which the given
// TSX ever renders. The CSS is the later revision; the bundled TSX is
// stale. List view below is rebuilt from the CSS's own class names/grid
// column count to match what "V2: no hidden swipe actions" actually
// describes, rather than porting the contradicted swipe-wrap markup.
// The edit/detail view below did NOT have this conflict (its classes all
// appear in both the TSX and CSS) and is ported as-is.
//
// Also fixed: the archive's icon paths (`/assets/field_*.webp`,
// `/assets/icon_*.webp`) don't match this app's actual asset layout
// (`/assets/field-types/...`, `/assets/ui-icons/...`) and a handful of
// literal `\n` escape sequences embedded as text in the source file
// (a mechanical corruption, not a design choice).
const FIELDS = [
  { id: 'product', name: K('제품명'), type: K('글자'), icon: '/assets/field-types/field_text.webp' },
  { id: 'brand', name: K('브랜드'), type: K('글자'), icon: '/assets/field-types/field_text.webp' },
  { id: 'category', name: K('카테고리'), type: K('선택'), icon: '/assets/field-types/field_select.webp' },
  { id: 'purchase', name: K('구매일'), type: K('날짜'), icon: '/assets/field-types/field_date.webp' },
  { id: 'price', name: K('가격'), type: K('금액'), icon: '/assets/field-types/field_currency.webp' },
  { id: 'rating', name: K('별점'), type: K('별점'), icon: '/assets/field-types/field_rating.webp' },
  { id: 'memo', name: K('메모'), type: K('긴 글'), icon: '/assets/field-types/field_edit_note.webp' },
];

export interface EditableField {
  name: string;
  kind: FieldKind;
  required: boolean;
  options: string[];
}

export interface DrawerFieldEditScreenProps {
  // A real field to edit. When given, the screen opens straight on the
  // edit view (#11's second state) for that field; without it the
  // archive's own demo list + demo field are shown (#26's manage route
  // still uses that until it is wired to a real drawer).
  field?: EditableField;
  onSave?: (patch: { name: string; required: boolean; options: string[] }) => void;
  onDelete?: () => void;
  // The archive's own TSX never wires this back button at all (see the
  // reconstruction note above) -- added so this screen can actually
  // return to whichever list screen reached it (#09's own `drawer-fields`
  // route, or #26's reuse of the same screen via `drawer-fields-manage`).
  onBack?: () => void;
}

export function DrawerFieldEditScreen({ field, onBack, onSave, onDelete }: DrawerFieldEditScreenProps) {
  const [mode, setMode] = useState<'list' | 'edit'>(field ? 'edit' : 'list');
  const [name, setName] = useState(field?.name ?? t('카테고리'));
  const [required, setRequired] = useState(field?.required ?? false);
  const [options, setOptions] = useState(field ? field.options : [t('스킨케어'), t('메이크업'), t('향수')]);
  const kind: FieldKind = field?.kind ?? 'select';
  const kindInfo = FIELD_TYPES.find((t) => t.kind === kind)!;
  const savedName = field?.name ?? t('카테고리');
  const [deleteOpen, setDeleteOpen] = useState(false);

  if (mode === 'list') {
    return (
      <section className="df-screen">
        <ScreenHeader variant="stacked" title={t('서랍 칸 정하기')} onBack={onBack} height={93} />
        <section className="df-content">
          <p className="df-intro">{tl('이 서랍에 어떤 내용을 기록할까요?\n원하는 서랍 칸을 직접 정할 수 있어요.')}</p>
          <p className="df-list-help">{tx('{field}을 누르면 수정할 수 있고,\n오른쪽 {handle}를 끌면 순서를 바꿀 수 있어요.', { field: <b>{t('서랍 칸')}</b>, handle: <b>{t('손잡이')}</b> })}</p>
          <div className="df-list">
            {FIELDS.map((field) => (
              <div className="df-row is-editable" key={field.id}>
                <button className="df-row-tap" aria-label={t('{name} 수정', { name: field.name })} onClick={() => setMode('edit')} />
                <div className="df-main"><img src={field.icon} alt="" /><strong>{field.name}</strong></div>
                <span className="df-type">{t(field.type)}</span>
                <span className="df-row-edit-hint" aria-hidden="true">›</span>
                <i className="df-divider" />
                <button className="df-handle" aria-label={t('{name} 순서 변경', { name: field.name })}><b /><b /><b /></button>
              </div>
            ))}
          </div>
          <button className="df-add">{t('＋ 서랍 칸 추가')}</button>
          <button className="df-complete">{t('서랍 만들기 완료하기')}</button>
        </section>
      </section>
    );
  }

  return (
    <section className="df-screen">
      <ScreenHeader variant="stacked" title={t('서랍 칸 수정')} onBack={field ? onBack : () => setMode('list')} height={93} />
      <section className="df-edit-content">
        <label className="df-label" htmlFor="field-name">{t('서랍 칸 이름')}</label>
        <div className="df-input-wrap">
          <input id="field-name" value={name} onChange={(e) => setName(e.target.value.slice(0, 20))} />
          <span>{name.length}/20</span>
        </div>

        <span className="df-label">{t('서랍 칸 종류')}</span>
        {/* A field's kind is fixed once created (its saved values would stop matching), so this row only shows it. */}
        <button className="df-selected-type" type="button" tabIndex={field ? -1 : 0} style={field ? { cursor: 'default' } : undefined}>
          <span className="df-type-icon"><img src={kindInfo.icon} alt="" /></span>
          <span className="df-type-copy"><strong>{kindInfo.label}</strong><small>{kindInfo.description}</small></span>
          <span className="df-chevron">›</span>
        </button>

        {kind === 'select' && <section className="df-options">
          <h2>{t('선택 옵션')}</h2>
          <div className="df-option-list">
            {options.map((option, index) => (
              <div className="df-option-row" key={index}>
                <input value={option} onChange={(e) => setOptions(options.map((v, i) => i === index ? e.target.value : v))} />
                <button onClick={() => setOptions(options.filter((_, i) => i !== index))}>−</button>
              </div>
            ))}
          </div>
          <button className="df-add-option" onClick={() => setOptions([...options, t('옵션 {n}', { n: options.length + 1 })])}>{t('＋ 옵션 추가')}</button>
        </section>}

        <div className="df-required">
          <div><strong>{t('필수로 채우기')}</strong><small>{t('보관품을 담을 때 꼭 채워야 하는 서랍 칸이에요.')}</small></div>
          <button className={`df-switch${required ? ' is-on' : ''}`} aria-pressed={required} aria-label={t('필수 입력')} onClick={() => setRequired(!required)}><span /></button>
        </div>

        <button className="df-save" onClick={() => onSave?.({ name, required, options })}>{t('저장하기')}</button>
        <button className="df-delete" onClick={() => setDeleteOpen(true)}><img src="/assets/ui-icons/icon_delete.webp" alt="" /> {t('서랍 칸 삭제')}</button>
        <p className="df-edit-danger-note">{t('삭제한 서랍 칸의 기존 입력값은 함께 사라져요.')}</p>
        {deleteOpen && (
          <div className="df-modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) setDeleteOpen(false); }}>
            <section className="df-confirm-sheet" role="dialog" aria-modal="true" aria-label={t('서랍 칸 삭제 확인')}>
              <div className="df-sheet-handle" />
              <div className="df-confirm-icon"><img src="/assets/ui-icons/icon_delete.webp" alt="" /></div>
              <h2>{t('이 서랍 칸을 삭제할까요?')}</h2>
              <p>{tl("'{name}' 서랍 칸과 여기에 담긴 입력값이 함께 삭제돼요.\n삭제한 뒤에는 되돌릴 수 없어요.", { name: savedName })}</p>
              <div className="df-confirm-actions">
                <button className="df-cancel" onClick={() => setDeleteOpen(false)}>{t('취소')}</button>
                <button className="df-confirm-delete" onClick={onDelete}>{t('삭제하기')}</button>
              </div>
            </section>
          </div>
        )}
      </section>
    </section>
  );
}
