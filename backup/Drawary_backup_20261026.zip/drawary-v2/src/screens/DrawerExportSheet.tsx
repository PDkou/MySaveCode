import { useState } from 'react';
import './TableSortFilterEntryScreen.css';
import './DrawerExportSheet.css';
import { revealSheet } from '../components/revealSheet';
import { t } from '../i18n';
import type { TableColumn } from '../flow/tableQuery';

export type ExportFormat = 'book' | 'table' | 'csv';
export interface ExportChoice { format: ExportFormat; columnIds: string[]; /** Photos in the collection PDF. */ withPhotos: boolean }

export interface DrawerExportSheetProps {
  /** The drawer's columns; the first one (the name) is always in. */
  columns: readonly TableColumn[];
  onCancel?: () => void;
  onExport?: (choice: ExportChoice) => void;
}

/**
 * 서랍 관리's "내보내기". No approved design exists for it, so it is drawn with #27's sheet (the same classes): the shape of the file
 * (a collection PDF to look at, a table PDF to keep, or CSV) and which columns go in. The whole-app backup stays in 설정 > 데이터 관리.
 */
export function DrawerExportSheet({ columns, onCancel, onExport }: DrawerExportSheetProps) {
  const [format, setFormat] = useState<ExportFormat>('book');
  const [off, setOff] = useState<ReadonlySet<string>>(new Set());
  const [photos, setPhotos] = useState(true);
  const options: { key: ExportFormat; title: string; body: string }[] = [
    { key: 'book', title: t('보기 좋은 도감 PDF'), body: t('표지와 사진이 들어가요. 남에게 보여주기 좋아요.') },
    { key: 'table', title: t('정리하기 좋은 표 PDF'), body: t('깔끔한 표예요. 보관하거나 인쇄하기 좋아요.') },
    { key: 'csv', title: t('CSV 파일'), body: t('엑셀 같은 앱에서 열 수 있어요.') },
  ];
  const toggle = (id: string) => setOff((prev) => { const next = new Set(prev); if (next.has(id)) next.delete(id); else next.add(id); return next; });
  return (
    <div className="tsf-backdrop" ref={revealSheet} role="presentation" onClick={onCancel}>
      <section className="tsf-sheet des-sheet" role="dialog" aria-modal="true" aria-labelledby="drawer-export-title" onClick={(e) => e.stopPropagation()}>
        <div className="tsf-handle" />
        <header className="tsf-head">
          <h2 id="drawer-export-title">{t('내보내기')}</h2>
          <p>{t('어떤 모양으로 만들까요?')}</p>
        </header>
        <div className="des-options" role="radiogroup">
          {options.map((o) => (
            <button key={o.key} type="button" role="radio" aria-checked={format === o.key} className={`des-option${format === o.key ? ' is-selected' : ''}`} onClick={() => setFormat(o.key)}>
              <span className="des-radio" aria-hidden="true" />
              <span className="tsf-copy"><strong>{o.title}</strong><span>{o.body}</span></span>
            </button>
          ))}
        </div>
        <div className="des-fields-head">
          <strong>{t('넣을 칸을 골라 주세요')}</strong>
          <span>{t('남에게 보여줄 거라면 가격을 빼 둘 수도 있어요.')}</span>
        </div>
        <div className="des-chips">
          {columns.map((c, i) => (
            <button key={c.id} type="button" className={`des-chip${off.has(c.id) ? ' is-off' : ''}`} aria-pressed={!off.has(c.id)} disabled={i === 0} onClick={() => toggle(c.id)}>{c.label}</button>
          ))}
          {format === 'book' && <button type="button" className={`des-chip${photos ? '' : ' is-off'}`} aria-pressed={photos} onClick={() => setPhotos((p) => !p)}>{t('사진')}</button>}
        </div>
        <p className="tsf-note des-note">{t('표 보기의 정렬과 필터가 적용돼요. 도감 PDF는 최근에 담은 순서예요.')}</p>
        <button type="button" className="des-go" onClick={() => onExport?.({ format, columnIds: columns.filter((c) => !off.has(c.id)).map((c) => c.id), withPhotos: photos })}>{t('내보내기')}</button>
        <button type="button" className="tsf-cancel" onClick={onCancel}>{t('취소')}</button>
      </section>
    </div>
  );
}
