import { useRef, type PointerEvent as ReactPointerEvent, type MouseEvent as ReactMouseEvent } from 'react';

export interface LongPressPoint { x: number; y: number; element: HTMLElement }

/**
 * Holding a finger (or the mouse) on something for about a second. Moving more than a few pixels before that is a scroll or a
 * drag, not a long press, so it is cancelled. When it fires, the tap that follows the release is swallowed, so what was held does
 * not also open. Spread the result onto the element.
 */
export function useLongPress(onLongPress: (point: LongPressPoint) => void, ms = 1000) {
  const timer = useRef<number | undefined>(undefined);
  const hint = useRef<number | undefined>(undefined);
  const held = useRef<HTMLElement | null>(null);
  const origin = useRef<{ x: number; y: number } | null>(null);
  const last = useRef({ x: 0, y: 0 });
  const fired = useRef(false);
  const callback = useRef(onLongPress);
  callback.current = onLongPress;

  /** The held element carries `lp-holding` between the first moment and the end of the hold, so the page can show it trembling. */
  const clearHint = () => { window.clearTimeout(hint.current); held.current?.classList.remove('lp-holding'); held.current = null; };
  const cancel = () => { window.clearTimeout(timer.current); origin.current = null; clearHint(); };
  return {
    onPointerDown: (e: ReactPointerEvent<HTMLElement>) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      fired.current = false;
      origin.current = { x: e.clientX, y: e.clientY };
      last.current = { x: e.clientX, y: e.clientY };
      const element = e.currentTarget;
      window.clearTimeout(timer.current);
      clearHint();
      held.current = element;
      hint.current = window.setTimeout(() => { if (origin.current) element.classList.add('lp-holding'); }, Math.min(350, ms / 3));
      timer.current = window.setTimeout(() => {
        if (!origin.current) return;
        fired.current = true;
        origin.current = null;
        clearHint();
        callback.current({ x: last.current.x, y: last.current.y, element });
      }, ms);
    },
    onPointerMove: (e: ReactPointerEvent<HTMLElement>) => {
      last.current = { x: e.clientX, y: e.clientY };
      const o = origin.current;
      if (o && Math.hypot(e.clientX - o.x, e.clientY - o.y) > 10) cancel();
    },
    onPointerUp: cancel,
    onPointerCancel: cancel,
    /** The phone may also send a context-menu event for a long press: it is ours, not the browser's. */
    onContextMenu: (e: ReactMouseEvent<HTMLElement>) => { e.preventDefault(); },
    onClickCapture: (e: ReactMouseEvent<HTMLElement>) => {
      if (!fired.current) return;
      fired.current = false;
      e.preventDefault();
      e.stopPropagation();
    },
  };
}
