# Play Console 등록 순서 (Hello, Today)

이 문서는 실제로 손으로 해야 하는 작업 체크리스트입니다 — Play Console
웹 UI 조작이나 실제 결제 흐름 검증은 이 저장소를 다루는 세션(AI 에이전트)이
대신해줄 수 없는 영역이라, 순서와 이 앱 특유의 주의사항만 정리해둡니다.

## 0. 시작 전에 준비할 것

- [x] **Google Play Console 개발자 계정** — **완료**
- [x] **개인정보처리방침(Privacy Policy) URL** — **완료** (2026-08-27).
      한국어(전문) + 영어(요약) 페이지를 만들어 Artifact로 발행함:
      https://claude.ai/code/artifact/f623cb28-a189-4cab-a294-b8fededc9bba
      ⚠️ **Artifact는 기본적으로 비공개**입니다 — Play Console 심사자와
      사용자가 볼 수 있으려면 페이지 우측 상단 공유 메뉴에서 반드시
      **공개(공유)로 전환**한 뒤, 그 URL을 앱 콘텐츠 → 개인정보처리방침
      칸에 붙여넣으세요. (연락처는 `db5704@gmail.com`로 실려 있음 — 다른
      주소로 바꾸고 싶으면 다음에 알려주면 바로 수정.)
- [x] **Feature graphic** (1024×500) — **완료** (2026-08-27, 2026-09-04에
      언어별로 3개로 분리): 아이콘 + 태그라인으로 구성, 언어별 파일:
      - `store-assets/feature-graphic-1024x500-en.png` ("In life's small
        gaps, a small hello.") — **기본 스토어 등록정보(English)**에 업로드
      - `store-assets/feature-graphic-1024x500-ko.png` ("하루의 틈에,
        작은 안부") — 한국어 번역 등록정보에 업로드
      - `store-assets/feature-graphic-1024x500-ja.png` ("日々のすきまに、
        小さな安否を。") — 日本語 번역 등록정보에 업로드
      다시 만들거나 문구를 바꾸고 싶으면 `store-assets/capture-feature-graphic.js`의
      `LOCALES`를 고쳐서 재실행 (`node capture-feature-graphic.js`).
- [x] **스크린샷 7장** (휴대폰, 1080×1920) — **완료** (2026-08-27):
      `store-assets/screenshots/01`~`07`.png. 온보딩 3장 → 오늘 화면(메모
      이월 포함) → 사람 목록 → 프리미엄 업셀 → 설정(테마)까지 앱의
      실제 화면을 `store-assets/capture-screenshots.js`로 캡처한 것
      (목업 아님). 데이터/카피가 바뀌면 스크립트만 다시 돌리면 최신 화면
      그대로 재생성됨.
- [x] 앱 아이콘 512×512 — **이미 있음**: `art/HelloToday-icon-512.png`
- [x] AAB를 서명할 업로드 키 — **완료**. 2026-08-27 세션에서 생성해
      직접 전달함 (`hellotoday-upload-key.jks` + `keystore.properties`).
      전달받은 파일을 안전한 곳에 보관하고, `keystore.properties`의
      `storeFile` 경로를 실제 저장 위치로 수정한 뒤
      `hellotoday-app/keystore.properties`에 두면 `./gradlew bundleRelease`가
      서명된 AAB를 만듭니다.
- [x] **AdMob 계정 + App ID / 광고 단위 ID** — **완료** (2026-08-27).
      App ID `ca-app-pub-4220607528679200~3458803740`, 전면 광고 단위 ID
      `ca-app-pub-4220607528679200/8936210332`를 `AndroidManifest.xml` /
      `InterstitialAdManager.java`에 반영, CI로 컴파일 검증까지 완료.
      ⚠️ 이제 Google 테스트 ID가 아니라 **실제 광고 단위**입니다 — 본인
      폰에서 반복 테스트하기 전에 AdMob 콘솔 **설정 → 테스트 기기**에
      그 폰을 등록해두세요, 안 그러면 잘못된 트래픽으로 계정이 정지될 수
      있습니다. 아래 3-1번에 UMP 동의 흐름이 아직 남아있습니다.

## 0-1. 알림 아이콘 수정 (0.4.15) — **완료** (2026-08-28)

`ReminderReceiver`/`NotificationActionReceiver`가 `setSmallIcon()`에
안드로이드 기본 시스템 "i" 아이콘(`android.R.drawable.ic_dialog_info`)을
쓰고 있던 걸 발견해서 앱 전용 상태바 아이콘(`ic_notification.xml`, 말풍선
실루엣)으로 교체. 버전 0.4.14(코드 28) → **0.4.15(코드 29)**로 올려서
CI로 다시 빌드 → 내부 테스트 트랙에 재업로드 완료.

## 0-2. 앱 이름 충돌 검토 — 확인 후 유지하기로 결정 (2026-08-28)

호주의 기존 서비스 **HelloToday**(hellotoday.com.au, "매일 체크인" 안부
확인 앱, iOS/Android 양쪽 정식 출시)와 이름이 사실상 동일함(쉼표
유무 차이). 상표/사칭 정책 리스크가 있다고 사용자에게 명시적으로
안내했으나, **사용자가 현재 이름("Hello, Today") 그대로 진행하기로
결정**함. 나중에 Google로부터 사칭/상표 관련 이의 제기를 받을 경우
이 판단을 참고할 것.

## 1. Play Console에서 새 앱 만들기

1. Play Console → **모든 앱** → **앱 만들기**
2. 앱 이름: `Hello, Today` / 기본 언어: 한국어
3. 앱 또는 게임: **앱** / 무료 또는 유료: **무료** (인앱 결제 있음 — 무료
   앱 + 인앱 상품 조합이 맞는 선택)
4. 선언 체크박스 진행

## 2. 앱 콘텐츠 (정책 준수 섹션) — **완료** (2026-08-28)

Play Console 좌측 메뉴 **정책 → 앱 콘텐츠**에서 전부 작성해야 다음 단계로
넘어갈 수 있습니다:

- **개인정보처리방침**: 위에서 준비한 URL 입력
- **광고**: **있음** (Google AdMob 전면 광고, 무료 버전에만 노출) — "광고
  없음"으로 잘못 체크하면 정책 위반으로 반려됩니다.
- **앱 액세스 권한**: 전체 공개(로그인 불필요 — 이 앱은 계정 자체가 없음)
- **콘텐츠 등급**: 설문 진행 (개인 정보 교환/생성 콘텐츠 없음, 전체이용가
  등급이 나올 것)
- **대상층 및 콘텐츠**: 만 13세 이상 등 실제 타겟에 맞게. 광고가 있으므로
  "아동 대상 여부" 질문에 정확히 답해야 함(아동 대상 앱은 개인 맞춤 광고에
  추가 제약이 있음).
- **뉴스 앱 여부**: 아니오
- **데이터 보안(Data safety) 양식**: 이 앱은
  - 사용자가 직접 입력하는 데이터(사람 이름·메모 등): **없음, 로컬에만
    저장** (`localStorage`/SharedPreferences, 서버 없음)
  - **광고 식별자(Advertising ID)**: **수집·공유함** — Google AdMob이
    광고 표시 목적으로 사용. 목적은 "광고"로 체크, 이 앱이 직접 저장하지는
    않음(Google이 처리)이라고 명시
  - Google Play 결제 자체가 발생시키는 최소한의 거래 정보는 Google이
    자체적으로 처리 — 앱이 직접 수집/전송하는 게 아니므로 이 항목은
    추가로 선언할 필요 없음 (Billing Library 표준 사용 시 일반적인 처리
    방식)

## 3. 인앱 상품 등록 — **정확한 ID가 중요**

- [x] **AAB 업로드** — **완료** (2026-08-28). Play Console 최신 UI에서는
  "일회성 제품"을 만들려면 먼저 앱에 AAB가 하나라도 올라가 있어야 함.
  `.github/workflows/build-hellotoday-release.yml` (CI, 리포지토리
  시크릿에 저장된 실제 서명 키로 `bundleRelease` 실행)로 빌드해서
  **테스트 및 출시 → 테스트 → 내부 테스트**에 첫 버전(0.4.14, 버전
  코드 28) 업로드/출시함.
- [x] **일회성 제품 `remove_ads` 생성 및 활성화** — **완료** (2026-08-28).
  **Play를 통한 수익 창출 → 제품 → 일회성 제품 → 제품 만들기**에서:
  - **제품 ID**: `remove_ads`
    (⚠️ `PremiumBilling.PRODUCT_ID`에 하드코딩된 값과 철자가 정확히
    일치함 — 다르면 `queryProductDetailsAsync`가 빈 결과를 반환하고
    구매 버튼이 계속 실패합니다.)
  - 구매 옵션(구매 유형: 구입) 추가, 가격 ₩2,900(모든 지역), **활성화**
    완료.

### 3-1. AdMob 연동

- [x] 계정 생성, 앱 추가, 전면 광고 단위 생성, App ID/광고 단위 ID를
  코드에 반영 — **완료** (2026-08-27). App ID
  `ca-app-pub-4220607528679200~3458803740`, 전면 광고 단위 ID
  `ca-app-pub-4220607528679200/8936210332`. CI로 컴파일 검증 완료.
- [x] **본인 테스트 기기를 AdMob 콘솔 → 설정 → 테스트 기기에 등록** —
  **완료** (2026-08-28). 폰의 광고 ID(설정 → Google → 광고)를 AdMob
  콘솔 → 설정 → 테스트 기기 → 기기 추가로 등록. 이제 이 폰에서는 실제
  광고 대신 테스트 광고가 나와 반복 확인해도 계정 정지 위험이 없음.
- [x] **User Messaging Platform(UMP) SDK 연동** — **완료** (2026-08-27):
  `ConsentManager.java`, CI로 컴파일 검증 완료. `MainActivity`가 광고
  시작 전에 항상 이걸 먼저 거치도록 배선함.
- [ ] **AdMob 콘솔에서 실제 동의 양식(GDPR) 만들기** — 시도했으나 **막힘**
  (2026-08-28). AdMob 콘솔 → 개인정보 및 메시지 → 유럽 규정에서 메시지를
  다 채워도 "게시" 버튼이 계속 비활성화됨. 원인 추정: AdMob이 앱을
  스토어에 연결(앱 → Hello, Today → "검토 필요")하려면 실제로 검색 가능한
  공개 Play 스토어 페이지가 있어야 하는데, 지금은 **내부 테스트만
  있어서** 그 페이지가 아직 존재하지 않음 (기기 인증 문제와는 별개 —
  기기 인증은 이미 완료됐는데도 안 풀림). 즉 **아래 5-1번의 비공개 테스트
  12명/14일 요건을 채우고 프로덕션(또는 최소 인덱싱되는 트랙)에 들어가야
  풀릴 가능성이 높음** — 지금 단계에서 더 시도해도 안 풀릴 수 있음.
  풀리는 대로 재시도. 만든 뒤엔 `ConsentDebugSettings`의 디버그 지역
  (geography) 오버라이드로 직접 여행 없이도 EEA 사용자 시나리오를 테스트
  기기에서 확인할 수 있음.

## 4-1. 신규 개인 개발자 계정 필수 요건: 비공개 테스트 12명/14일

2023-11-13 이후 생성된 개인 개발자 계정은 **비공개 테스트(Closed
testing)** 트랙에서 **최소 12명**이 **14일 연속** 옵트인 상태를 유지해야
Play Console 대시보드에서 "프로덕션 액세스"를 신청할 수 있음 — 이 계정도
해당됨. **주의: 지금까지 쓴 "내부 테스트"는 이 요건에 카운트되지
않음** — 별도로 비공개 테스트 트랙을 새로 만들어야 함.

- [x] **비공개 테스트 트랙 생성, AAB 업로드** — **완료** (2026-08-28).
  "비공개 테스트 - hello,today테스트트랙" 사용 (Play Console이 앱 생성
  시 기본으로 만들어둔 트랙), 0.4.16 업로드, 국가 "모든 국가"로 설정,
  검토를 위해 Google에 전송 완료.
- [ ] **테스터 12명 이상 이메일 등록** — 진행 중. 실제 사람이 옵트인
  링크로 실제 참여(설치까지 완료)해야 카운트됨 — 이메일만 등록해두고
  안 열어보면 카운트 안 됨. 테스터 전달문(맨 아래 섹션)으로 모집 중.
- [ ] 14일 연속 유지 확인 후 프로덕션 액세스 신청 (Play Console
  대시보드에 진행 상황이 표시됨)

Sources: [새로운 개인 개발자 계정의 앱 테스트 요구사항](https://support.google.com/googleplay/android-developer/answer/14151465?hl=ko),
[공개, 비공개, 내부 테스트 설정](https://support.google.com/googleplay/android-developer/answer/9845334?hl=ko)

## 4. 스토어 등록정보 (Store listing)

- 앱 이름: `Hello, Today`
- 짧은 설명 (80자 이내, 아래 그대로 붙여넣기 가능 — 28자):

  > 가끔 생각나는 사람에게, 잊지 않고 안부를 전해요.

- 전체 설명 (4000자 이내, 아래 그대로 붙여넣기 가능):

  ```
  가끔 생각나는 사람이 있나요?
  Hello, Today는 그런 분들을 위한 아주 작고 조용한 안부 리마인더 앱이에요.

  📮 이런 앱이에요
  - 연락하고 싶은 사람을 등록해두면, 적당한 때에 알림으로 알려드려요.
  - 연락한 뒤엔 짧은 메모를 남길 수 있어요. 다음에 연락할 때 "지난번에 남긴 메모"로 다시 보여드립니다.
  - 알림 주기는 랜덤(14~28일 중 하루)이나 고정 간격 중 골라 쓸 수 있어요.
  - 조용한 시간대를 정해두면 그 시간엔 알림이 오지 않아요.

  🔒 개인정보
  - 회원가입도 로그인도 없어요. 모든 기록은 이 기기 안에만 저장됩니다.
  - 서버가 없어서, 저희를 포함해 누구도 이 데이터에 접근할 수 없어요.
  - 설정에서 언제든 모든 데이터를 즉시 삭제할 수 있습니다.

  🎨 취향껏 꾸미기
  - 크림 · 세이지 · 라일락 · 피치 · 스카이 · 피스타치오, 6가지 테마 중 골라보세요.
  - 한국어, 日本語, English 지원.

  💛 무료로 2명까지
  무료 버전은 사람을 2명까지 등록할 수 있고, 가끔 광고가 나와요.
  "광고 제거"를 구매하면 광고도 없어지고 인원 제한도 함께 풀립니다.
  ```

### 4-1. English store listing (2026-09-14 번역)

- Short description (under 80 chars — 66 chars):

  > A small, quiet reminder to reach out to the people you think of.

- Full description (under 4000 chars):

  ```
  Is there someone you think of now and then?
  Hello, Today is a small, quiet reminder app for staying in touch with them.

  📮 What it does
  - Add someone you want to reach out to, and you'll get a reminder at just the right time.
  - After you reach out, leave a short note. Next time, it resurfaces "what you talked about last time."
  - Choose a random schedule (once every 14–28 days) or a fixed interval.
  - Set quiet hours, and no reminders will arrive during that time.

  🔒 Privacy
  - No sign-up, no login. Everything is stored only on this device.
  - There's no server, so no one — not even us — can access your data.
  - Delete all your data instantly, anytime, from Settings.

  🎨 Make it yours
  - Choose from 6 themes: Cream, Sage, Lilac, Peach, Sky, and Pistachio.
  - Supports Korean, Japanese, and English.

  💛 Free for up to 2 people
  The free version supports up to 2 people, with the occasional ad.
  Remove ads to also lift the people limit.
  ```

### 4-2. 日本語ストア掲載情報 (2026-09-14 翻訳)

- 簡単な説明(80文字以内 — 30文字):

  > たまに思い出すあの人に、そっと安否を伝えるリマインダーアプリ。

- 詳細な説明(4000文字以内):

  ```
  たまに思い出す人はいますか？
  Hello, Todayは、そんな相手のための、とても小さくて静かな安否リマインダーアプリです。

  📮 こんなアプリです
  - 連絡したい相手を登録しておくと、ちょうどいいタイミングで通知でお知らせします。
  - 連絡した後は短いメモを残せます。次に連絡するときに「前回のメモ」として再び表示されます。
  - 通知の間隔は、ランダム(14〜28日の間のどこか)か固定間隔から選べます。
  - 通知を止めたい時間帯を設定しておけば、その時間には通知が届きません。

  🔒 プライバシー
  - 会員登録もログインも不要です。記録はすべてこの端末内にのみ保存されます。
  - サーバーがないため、私たちを含め誰もこのデータにアクセスできません。
  - 設定からいつでもすべてのデータを即座に削除できます。

  🎨 好みに合わせてカスタマイズ
  - クリーム・セージ・ライラック・ピーチ・スカイ・ピスタチオ、6種類のテーマから選べます。
  - 韓国語・日本語・英語に対応しています。

  💛 無料で2人まで
  無料版では2人まで登録でき、たまに広告が表示されます。
  「広告削除」を購入すると、広告がなくなり人数制限も解除されます。
  ```

- 아이콘: `art/HelloToday-icon-512.png` 업로드
- Feature graphic, 스크린샷 업로드 (위 0번 항목에서 준비한 것)

## 5. AAB 빌드 & 비공개 테스트(Closed testing) 트랙에 업로드

```bash
cd hellotoday-app
# keystore.properties가 준비돼 있어야 함 (0번 항목 참고)
./gradlew bundleRelease
# -> app/build/outputs/bundle/release/app-release.aab
```

**프로덕션으로 바로 가지 말고** Play Console → **Testing → Closed testing**에서
새 테스트 트랙을 만들어 여기에 먼저 업로드하세요:

1. 트랙 이름 설정 (예: "비공개 테스트")
2. `app-release.aab` 업로드
3. **테스터**: 이메일 목록 직접 추가, 또는 구글 그룹스 이메일 등록
4. 저장 → 검토용으로 제출 (신규 앱은 최초 1회 Google 정책 검토가 필요할
   수 있음 — 프로덕션 심사보다는 통상 가볍지만 즉시 통과를 보장하지 않음)
5. 검토/게시 완료 후 Play Console이 **옵트인(참여) 링크**를 발급함 —
   이 링크를 테스터에게 전달 (아래 "테스터 전달문" 참고)

## 6. 테스터에게 공유하기

아래 "테스터 전달문" 섹션 텍스트에서 `[테스트 참여 링크]` 부분을 실제
옵트인 링크로 바꿔서 전달하면 됩니다.

## 7. 광고 제거 구매 + 광고 노출 실제 검증

- [x] **신규 개인 개발자 계정의 "기기 인증"** — **완료** (2026-08-28).
  Google이 2024년부터 요구하는 절차: 실기기에 Play 스토어 앱 "Google Play
  Console" 설치 → 개발자 계정 소유자로 로그인. 이걸 안 하면 내부 테스트
  옵트인 링크가 "항목을 찾을 수 없습니다"로 뜨고, AdMob에서도 앱을 스토어에
  연결할 수 없음 — 한동안 이 원인을 몰라 "Play 심사가 안 끝나서 그런가"로
  착각했었음. 실제로는 심사와 무관한, 계정 차원의 1회성 인증 절차였음.
- [x] **광고 실제 노출 검증** — **완료** (2026-08-28). 실기기(테스트 기기
  등록됨)에서 "연락했어요" 3번 반복 → 테스트 광고 노출 확인.
  ⚠️ 이 과정에서 버그 발견: `InterstitialAdManager`가 광고 로딩 실패 시
  재시도를 안 해서, 최초 로딩이 늦거나 실패하면 그 세션 내내 광고가 영영
  안 뜨는 상태로 남았음. `maybeShow()`가 로딩된 광고가 없을 때 즉시
  재시도를 걸도록 수정(버전 0.4.16, versionCode 30) → 재검증 완료.
- [x] **광고 제거 구매 흐름 실기기 검증** — **완료** (2026-08-28). 라이선스
  테스터(`db5704@gmail.com`, RESPOND_NORMALLY)로 등록 후 실기기에서
  3번째 사람 등록 시도 → "광고 제거" 시트 → 구매 UI 정상 표시(상품명/
  패키지명/가격) → 원탭 구매 → 인원 제한 해제 확인, 이후 "연락했어요"
  반복해도 광고 더 이상 안 뜨는 것까지 확인.

## 8. 알림 아이콘 & 정시 알림 버그 — 실기기 검증

0.4.18 설치 후 실기기 재테스트에서 발견/수정:

- [x] **알림 아이콘이 카카오톡 아이콘과 구분 안 됨** — **완료** (0.4.18).
  단순 말풍선 모양이 상태바에서 카카오톡 아이콘과 너무 비슷해 보임.
  브랜드 아이덴티티(말풍선 안에 하트)를 그대로 살려 `ic_notification.xml`을
  말풍선 안에 하트를 오려낸 실루엣(fillType=evenOdd)으로 교체. 실기기에서
  확인 완료.
- [x] **테스트 알림이 5분이 지나도 안 오고 앱을 재실행해야만 옴** —
  **완료** (0.4.19). 원인 두 단계:
  1. `ReminderScheduler.schedule()`이 `setAndAllowWhileIdle()`(부정확,
     OEM 배터리 최적화가 지연 가능)만 쓰고 있었음 → `SCHEDULE_EXACT_ALARM`
     권한 확인 후 `setExactAndAllowWhileIdle()`을 우선 사용하도록 수정
     (0.4.18).
  2. 그런데도 여전히 재현됨 — 원인은 그 권한을 요청하는 코드가 온보딩
     튜토리얼 종료 시(`finishTutorial()`) 딱 한 번만 호출되게 되어 있어서,
     이미 예전 버전에서 튜토리얼을 끝낸 기존 유저(개발자 본인 기기 포함)는
     이번에 새로 추가된 권한 요청 화면을 아예 한 번도 본 적이 없었음.
     `MainActivity.onCreate()`에서 앱을 켤 때마다(이미 허용됐으면
     `canScheduleExactAlarms()`가 no-op 처리) 무조건 확인하도록 수정
     (0.4.19) → 앱을 안 띄운 채로 5분 후 정시 도착 확인 완료.
- [x] **갤럭시 워치(웨어러블)에 알림이 안 뜸** — **완료** (2026-08-31).
  예상대로 앱 코드 문제가 아니었음 — 갤럭시 웨어러블 앱에서 Hello, Today
  앱별 알림 허용 설정을 켜니 정상적으로 워치에도 미러링됨. 앱 코드 변경
  없음.

---

## 테스터 전달문 (복사해서 사용하세요)

> 안녕하십니까
>
> 요즘 개인적으로 만들고 있는 앱, **"Hello, Today"**를 테스트해주셨으면 해요.
> 가끔 생각나는 사람한테 안부를 전하거나 연락해야되는데라고 자꾸 망설여지시는 분들을 위해,
> 심플하고 조용한 앱이에요. 가입이나 로그인도 없고, 모든 기록은 오로지 휴대폰
> 안에만 저장됩니다.
>
> **참여 방법** (두 단계 다 해주셔야 해요)
> 1. 먼저 이 구글 그룹에 가입해주세요: https://groups.google.com/g/hello-today-testers
> 2. 그다음 이 링크로 들어가서 "테스터 되기(Become a tester)"를 눌러주세요:
>    https://play.google.com/store/apps/details?id=com.howlingcreativestudio.hellotoday
> 3. 안내에 따라 Play 스토어에서 설치하시면 돼요.
>
> **이런 걸 봐주시면 좋아요**
> - 사람을 등록하고, 알림이 잘 오는지
> - "연락했어요" 누르고 메모 남기는 흐름이 자연스러운지 (연락했어요를 3번 누르면 광고가 뜰 수
>   있어요 — 테스트 중이라 나오는 임시 광고이니 신경 쓰지 않으셔도 돼요)
> - 사람을 3명째 등록하려고 할 때 나오는 "광고 제거" 안내 화면 — 문구나 흐름이
>   어색하지 않은지 (실제 결제까지는 하시면 안돼요! 진짜 돈나가요 ㅠㅠ)
> - 알림 시간/테마 등 설정 화면이 헷갈리지 않는지
>
> 불편하거나 이상한 점, 사소한 것도 편하게 말씀해주세요. 큰 도움이 됩니다.
> 사용해주셔서 미리 감사드려요 🙇
>
> — Howling Creative Studio

(영어/일본어 테스터에게는 앱 자체가 이미 ko/ja/en 다국어를 지원하니,
같은 내용을 해당 언어로 옮겨서 보내면 됩니다.)

## 커뮤니티 모집 글 (요즘IT, 디스콰이엇, 오픈카톡 앱테스트방 등)

지인 대상 "테스터 전달문"과 달리, **처음 보는 사람**이 읽는다는 전제로
앱 소개부터 시작하는 버전입니다. 12명 채우기 전까지는 이 글을 여러
커뮤니티에 올려서 모집하는 게 현실적입니다.

> 안녕하세요, 처음으로 개인 개발 앱을 하나 만들었습니다. 그래서 지금 **비공개 테스트
> 참여자**를 모집하고 있어요. 🙇
>
> **Hello, Today** — 가끔 생각나는 사람에게 안부를 전하고 싶은데 자꾸
> 잊어버리는 분들을 위한, 심플한 리마인더 앱입니다.
> - 연락하고 싶은 사람을 등록해두면 14~28일 사이 랜덤한 날에 알림으로
>   알려줘요.
> - 연락한 뒤엔 짧은 메모를 남길 수 있고, 다음에 다시 알려줄 때 그
>   메모를 보여줘요.
> - 회원가입/로그인 없음, 모든 기록은 기기 안에만 저장됩니다.
> - 한국어/日本語/English 지원.
>
> Play 스토어 정책상 **개인 개발자 계정이 신규일 경우, 비공개 테스트에
> 최소 12명이 참여해야 정식 출시가 가능**해서, 참여해주실 분을 찾고
> 있습니다.
>
> **참여 방법** (두 단계 다 해주셔야 참여로 인정됩니다)
> 1. 먼저 이 구글 그룹에 가입해주세요 (승인 대기 없이 바로 가입됩니다):
>    https://groups.google.com/g/hello-today-testers
> 2. 그다음 이 링크에서 "테스터 되기"를 누르고 Play 스토어에서 설치해주세요:
>    https://play.google.com/store/apps/details?id=com.howlingcreativestudio.hellotoday
> 3. 한 번 실행만 해주셔도 큰 도움이 됩니다 (계속 쓰실 필요는 없어요!).
>
> 앱을 써보시고 불편한 점이나 의견 있으시면 편하게 댓글/DM 남겨주세요.
> 시간 내주셔서 감사합니다!

### English version (Reddit r/androidapps, r/AlphaAndBetaUsers, IndieHackers 등)

> Hi! I'm an indie developer looking for **closed testers** for my Android
> app. 🙇
>
> **Hello, Today** — a quiet reminder app for staying in touch with people
> you keep meaning to contact but forget to.
> - Add someone you want to reach out to, and it reminds you on a random
>   day 14–28 days later.
> - Leave a short note after reaching out; it resurfaces that note next
>   time you're reminded.
> - No sign-up, no login — everything stays on your device (no server).
> - Supports Korean, Japanese, and English.
>
> Google Play requires new personal developer accounts to have at least
> 12 closed testers before going live, so I'm looking for people willing
> to help out.
>
> **To join** (both steps needed to count):
> 1. Join this Google Group first: https://groups.google.com/g/hello-today-testers
> 2. Then tap "Become a tester" here and install from Play: https://play.google.com/store/apps/details?id=com.howlingcreativestudio.hellotoday
> 3. Opening the app once is enough to help — no need to keep using it.
>
> Feedback (bugs, confusing screens, anything) is very welcome in the
> comments/DMs. Thanks so much for your time!

### 日本語版（Reddit r/Android_jp、5ch アプリ板、Discordのアプリテストコミュニティなど）

> こんにちは、個人でAndroidアプリを開発していて、**非公開テストの参加者**を
> 募集しています。🙇
>
> **Hello, Today** — たまに思い出す相手についつい連絡し忘れてしまう方の
> ための、静かなリマインダーアプリです。
> - 連絡したい相手を登録しておくと、14〜28日後のランダムな日に通知でお知らせします。
> - 連絡した後に短いメモを残せて、次にお知らせする時にそのメモを表示します。
> - 会員登録・ログイン不要、記録はすべて端末内のみに保存（サーバーなし）。
> - 韓国語・日本語・英語に対応。
>
> Google Playの規定で、新規の個人開発者アカウントは非公開テストに
> 最低12人の参加が必要なため、協力してくださる方を探しています。
>
> **参加方法**（両方の手順が必要です）
> 1. まずこちらのGoogleグループに参加してください：https://groups.google.com/g/hello-today-testers
> 2. 次にこちらのリンクから「テスターになる」を押してPlayストアからインストールしてください：https://play.google.com/store/apps/details?id=com.howlingcreativestudio.hellotoday
> 3. 一度起動していただくだけで大丈夫です（継続的な利用は不要です）。
>
> 使ってみての不具合や気になる点、気軽にコメント・DMでお知らせください。
> お時間いただきありがとうございます！

(플랫폼별로 첫 인사말/말투만 살짝 조정해서 쓰면 됩니다 — 링크는 위
"테스터 전달문"과 동일한 옵트인 링크를 넣으면 됩니다.)

---

## 9. 정식 출시(프로덕션) 전환 시 체크리스트 (2026-09-13 정리)

비공개 테스트 이후 실제 프로덕션으로 넘어갈 때 확인/처리할 것들. 위
0~8번은 비공개 테스트 단계 기준이고, 여기부터는 그 다음 단계.

### 9-0. 게이트 (이게 안 풀리면 프로덕션 자체가 안 열림)

- [ ] 비공개 테스트 **12명 / 14일 연속** 요건 충족 확인 (Play Console
  대시보드에 "프로덕션 액세스 신청 가능" 표시되는지)
- [ ] 요건 충족되면 **프로덕션 액세스 신청**

### 9-1. Play Console에서 손으로 처리

- [x] **AdMob UMP(GDPR) 동의 양식 생성** — **완료** (2026-09-15).
  "동의하지 않음" 버튼이 국가별로 비어있던 게 실제 원인이었음(기본값
  그대로 전부 켜진 상태로 확인만 누르면 됨) — 예전에 추정했던 "공개
  스토어 페이지 부재"는 이번엔 원인이 아니었음. 개인정보 보호 및
  메시지 → 유럽 규정에 "게시됨" 상태로 확인됨.
- [~] **`SCHEDULE_EXACT_ALARM` 권한 사용 목적 선언** — **2026-09-15
  확인: 지금은 대기 중 아님.** 앱 콘텐츠 → "주의 필요" 탭에 아무것도
  없음("모두 확인했습니다")이라, 현재 구글이 이 권한에 대한 별도
  소명을 요구하고 있지 않음. 프로덕션 심사 중 구글이 요청하면(이메일
  또는 새 "주의 필요" 항목) 그때 아래 문구를 그대로 제출하면 됨 —
  지금 추가로 할 일 없음. 그대로 붙여넣을 수 있는 영문
  소명 문구(2026-09-14 작성):

  ```
  Core functionality: Hello, Today is a personal reminder app whose
  entire purpose is nudging the user to reach out to specific people
  (e.g. family, friends) at a time the user has chosen or that the app
  has picked for them (either a fixed interval or a random day within a
  user-configured range).

  Why exact alarms are required: the app's core value proposition is
  that a reminder arrives at approximately the intended time -- not
  "sometime later that day" or "whenever the OS gets around to it."
  Without SCHEDULE_EXACT_ALARM, Android's battery-optimization behavior
  (especially on OEM skins such as Samsung's) can defer delivery of an
  inexact alarm by many minutes to hours, which directly undermines the
  app's single feature.

  How it's requested: the permission is requested through the standard
  system settings screen (ACTION_REQUEST_SCHEDULE_EXACT_ALARM), not
  silently, and it is used exclusively to schedule the user's own
  reminders that they configured inside the app -- no other feature in
  the app relies on exact alarms.
  ```

  한국어 버전(수정용 초안 — 실제 제출은 영어 권장이지만 초안 검토는
  이걸로):

  ```
  핵심 기능: Hello, Today는 개인용 리마인더 앱으로, 앱의 존재 이유가
  사용자가 직접 고른(또는 앱이 자동으로 골라준 고정 간격/범위 내
  랜덤 날짜) 시각에 특정 사람(가족, 친구 등)에게 연락하도록 알려주는
  것 하나뿐입니다.

  정확한 알람이 필요한 이유: 이 앱의 핵심 가치는 알림이 "그날 중
  아무 때나" 또는 "OS가 처리해줄 때"가 아니라, 사용자가 의도한 시각에
  가깝게 도착하는 것입니다. SCHEDULE_EXACT_ALARM 없이는 안드로이드의
  배터리 최적화(특히 삼성 등 일부 제조사 커스텀 UI)로 인해 부정확한
  알람이 수십 분에서 몇 시간까지 지연될 수 있고, 이는 이 앱의 유일한
  기능을 직접적으로 무력화시킵니다.

  요청 방식: 이 권한은 시스템 설정 화면(ACTION_REQUEST_SCHEDULE_EXACT_ALARM)을
  통해 명시적으로 요청되며(몰래 요청하지 않음), 사용자가 앱 안에서
  직접 설정한 리마인더를 예약하는 용도로만 사용됩니다 — 그 외 다른
  어떤 기능도 정확한 알람에 의존하지 않습니다.
  ```
- [x] **데이터 보안(Data safety) 양식 최신화** — **확인 완료, 수정
  불필요** (2026-09-15). CSV 내보내기로 실제 제출된 값 확인함:
  "기기 또는 기타 ID"(광고 ID)만 수집+공유(광고 목적, AdMob)로
  체크돼 있고 나머지(사진/동영상, 오디오 파일, 연락처, 개인 정보 등)
  는 전부 미체크 상태. Play의 "수집됨" 정의가 "기기 밖으로 전송됨"
  이라서, 프로필 사진·통화 녹음 연결처럼 순수 로컬 참조만 하는
  기능은 애초에 체크 대상이 아님 — 지금 상태가 정확함. 데이터
  삭제 URL도 개인정보처리방침의 `#delete-data`로 정상 연결됨.
- [x] **스토어 등록정보 영어/일본어 전체 설명** — **완료** (2026-09-14).
  4-1/4-2 섹션에 번역 완료, Play Console의 언어별 번역 등록정보에
  붙여넣기만 하면 됨.
- [x] **`remove_ads` 상품 가격/지역 정책** — **완료/확인됨**
  (2026-09-15). Play Console에서 일본 가격이 이미 **JPY 330 (VAT
  없음, 사용 가능)**로 설정돼 있는 걸 확인 — 앱 내 `특定商取引法に
  基づく表示`의 "330円(税込)"과 정확히 일치. 코드 수정 불필요.
- [x] **특정상거래법 표시 최종 확인** — **완료** (2026-09-15).
  가격(330円) Play Console 실제 설정값과 일치 확인. 운영총괄책임자/
  이메일/소재지 공개 방식은 기존 그대로 유지(개인 개발자에게 허용된
  "청구 시 공개" 방식).
- [x] **개인정보처리방침 Artifact 공개 상태 유지 확인** — **완료**
  (2026-09-15). 공유 링크로 접근 가능한 공개 상태 확인함. 동시에
  8/27 이후 추가된 프로필 사진·통화 녹음 파일 연결 기능이 본문에
  전혀 언급되지 않은 걸 발견해서, 두 기능 다 "기기 내 선택만, 서버
  업로드 없음"으로 명시하는 문단을 한/영 버전 모두에 추가하고 최종
  업데이트 날짜를 9/15로 갱신함(SCHEDULE_EXACT_ALARM 권한 설명도
  누락돼 있어 같이 추가).

### 9-2. 코드에서 처리할 것

- [x] **"테스트 알림" 설정 항목 문구를 사용자 친화적으로 변경** —
  **완료** (2026-09-15). 라벨을 "알림 확인"/"通知確認"/"Check
  notifications"으로 교체(기능 자체는 그대로 유지, 부제목에 "테스트로
  도착해요"라고 남겨 동작 방식은 계속 알 수 있게 함).
  `testNotification()`의 toast 문구에서도 "테스트" 단어 제거.
- [ ] versionName을 "1.0.0"으로 올릴지 결정 (선택 사항, Google이 강제
  하지 않음)
- [ ] 그 외 서명키/광고 ID/권한 목록은 이미 실제 운영값으로 세팅되어
  있어 추가 코드 변경 불필요.

## 10. 나중에 할 일 (Backlog, 정식 출시와 무관 — 급하지 않음)

- [ ] **대화면/폴더블 대응** (2026-09-16 메모). Play 콘솔 프리론치
  리포트에 계속 뜨는 "다음 출시 버전을 위한 발견 항목" 3건 중
  2건이 `screenOrientation="portrait"` 고정 및 대화면 미대응과
  관련됨(광고성 경고이며 정책 위반 아님, 출시 차단 안 함 — 지금은
  그냥 두기로 결정). 다만 폴더블폰 보급이 계속 늘어날 걸 감안하면
  언젠가는 손볼 필요가 있음. 실제로 손댈 때 예상 작업:
  - `AndroidManifest.xml`의 세로 고정(`screenOrientation="portrait"`)
    해제 여부 결정
  - `index.html`은 웹뷰 기반이라 반응형 CSS로 대응 가능한 구조 —
    카드/리스트가 큰 화면에서 늘어지지 않게 max-width, 2단 레이아웃
    등 조정
  - 폴더블/대화면 에뮬레이터(또는 실기기)로 실제 검증 필요
  - 우선순위: 정식 출시 이후, 급하지 않음

- [ ] **R8/ProGuard 코드 축소(minification) 활성화 — ⚠️ 기한 4개월 전
  (2026-10-14 기준)**. 1.0.0 프로덕션 출시 심사 중 Play Console
  "확인 필요" 탭에 "DEX 코드 최적화가 기준점 미만입니다"(난독화 비율
  1%, 기준 25%) 경고 발견. 해결 기한 **2027년 2월** — 처음엔 "1년 넘게
  남았다"고 잘못 계산했었는데, 실제로는 **4개월 정도**밖에 안 남음.
  1.0.1은 할로윈 아이콘 전용 버전으로 써버려서(12번 참고) 여기엔 아직
  미적용. **11월 초, 마케팅/할로윈 작업 정리되는 대로 착수 필요** —
  keep 규칙 작성 + 실기기 검증까지 포함하면 하루이틀로 안 끝나니 미리
  일정 잡을 것.
  - `app/build.gradle.kts`의 `buildTypes.release.isMinifyEnabled`를
    `true`로 변경 + `proguardFiles` 설정 필요
  - ⚠️ 이 앱은 WebView의 `@JavascriptInterface`(`HelloNative` 브릿지,
    `MainActivity.java`)로 JS↔Java를 리플렉션으로 연결하고 있어서,
    keep 규칙 없이 R8을 켜면 그 메서드들이 날아가 알림 저장/구매/
    리뷰 요청이 조용히 깨질 수 있음 — `proguard-rules.pro`에
    `@JavascriptInterface` 붙은 클래스/메서드 전체를 명시적으로 keep
    해야 함. Billing Library, AdMob/UMP, Play In-App Review 라이브러리도
    각자 자체 consumer-rules를 갖고 있긴 하지만 확인 필요.
  - 이 저장소 샌드박스엔 실기기/에뮬레이터가 없어 R8 켠 빌드를 직접
    검증할 수 없음 — **반드시 실기기에 설치해서 전체 기능(브릿지 호출,
    결제, 광고, 리뷰 요청) 수동 검증 후 배포**할 것
  - 우선순위: **11월 초 착수 목표** (기한 2027-02, 남은 기간 약 4개월)

## 11. 1.0.0 프로덕션 심사 결과 이후 체크리스트 (2026-10-06 작성)

2026-10-06 제출 → **승인됨, 스토어 페이지 공개 확인 완료.**

### 11-1. 승인된 경우

- [x] **Play 스토어 공개 확인**: 완료 (2026-10-06). 직접 접속해서 확인함
  (`https://play.google.com/store/apps/details?id=com.howlingcreativestudio.hellotoday`)
- [x] **AdMob app-ads.txt / 앱 인증 문제 — 해결 완료** (2026-10-06 ~
  2026-10-08). 스토어 공개 직후 AdMob 콘솔에 "Hello, Today(Android)을
  (를) 확인할 수 없습니다" — app-ads.txt 인증 실패 경고 발견. 원인:
  회사 웹사이트 자체가 없어서 app-ads.txt를 올려둘 도메인이 없었음.
  조치: GitHub organization `Howling-Creative-Studio` 신설 → 무료
  GitHub Pages 저장소 `Howling-Creative-Studio.github.io` 생성 →
  `app-ads.txt`(AdMob 발급 코드:
  `google.com, pub-4220607528679200, DIRECT, f08c47fec0942fa0`) +
  브랜드 톤에 맞춘 간단한 소개 페이지(`index.html`, Hello, Today Play
  스토어 링크 포함) 커밋/푸시 → Play Console 스토어 등록정보 연락처
  세부정보의 "웹사이트" 필드에 `https://howling-creative-studio.github.io`
  등록 → 이후에도 "확인 안됨"이 지속돼 `robots.txt`(`User-agent:
  Google-adstxt` / `Disallow:` 명시 허용)까지 추가 → **2026-10-08,
  AdMob "앱 인증" 상태가 "확인됨"으로 전환 확인.** "승인 상태"는 아직
  "준비 중"이지만 이는 정상적인 다음 단계(실사용자 트래픽 누적 대기)로,
  에러 아님. 이제 Howling Creative Studio의 공식 웹사이트 역할도 겸하게
  됨 — 앞으로 Play Console 등 다른 곳에 "웹사이트" 입력란이 필요하면
  이 주소를 쓰면 됨.
- [x] **Android 바이탈 모니터링 시작** (품질 → Android 바이탈) — 확인
  완료 (2026-10-08). 지난 28일 기준 크래시율/ANR률/콜드스타트 전부
  "데이터 없음"(설치 수가 적어 정상), 정책 상태 "문제 없음", 평점
  데이터 없음(리뷰 아직 없음). "조치 취하기"에 뜬 DEX 코드 최적화
  경고는 기존에 파악하고 있던 항목(R8/ProGuard 백로그, 기한
  2027-02)과 동일 — 새로운 문제 아님. 설치가 늘면 주기적으로 재확인.
- [x] **AdMob 콘솔 재확인**: 완료 (2026-10-08). "앱 인증" 상태가
  "확인됨"으로 전환된 것으로 스토어 연결 문제도 함께 해소된 것으로
  판단.
- [ ] **실사용자 AdMob 지표 확인**: 노출수/수익이 실제로 들어오기
  시작하는지 — 지금까지는 비공개 테스터 트래픽(요청 83건)만 있었음
- [ ] **`remove_ads` 인앱결제 실제 구매 발생 확인**: Play Console
  수익 창출 리포트에서 첫 실구매 발생 여부 체크
- [x] ~~비공개 테스트 트랙 테스터들에게 정식 출시 소식 전달~~ — 스킵
  결정 (2026-10-07). 테스터 다수가 도플리 경유라 개인적 감사 인사
  톤이 안 맞는다고 판단.
- [ ] **개발일지(Hatena) 다음 편 작성**: "정식 출시했습니다" 편으로
  시리즈 이어가기 좋은 타이밍
- [ ] 마케팅 실행 재논의 (감성 숏폼, ASO, 커뮤니티 홍보 — 이전에
  "나중에"로 미뤄뒀던 것들, 지금이 바로 그 타이밍)
- [ ] 여유 생기면 10번 백로그 항목(R8/ProGuard, 대화면 대응) 착수 검토

### 11-2. 반려된 경우

- [ ] Play Console에 뜨는 반려 사유 원문 전체 확인 (스크린샷으로
  공유해주면 같이 읽고 판단)
- [ ] 비공개 테스트 트랙은 그대로 살아있으니 서비스 중단 없음 — 급하게
  뭘 끌 필요는 없음
- [ ] 사유가 코드/정책 문제면: 해당 항목 수정 → versionCode 올려 재빌드
  → 재제출
- [ ] 사유가 불분명하거나 일반 템플릿이면: 지금까지처럼 추가로 점검할
  만한 부분(권한 사용 목적, 데이터 보안 양식, 콘텐츠 등급 등) 다시
  훑어보고 재제출 전략 같이 논의

## 12. 할로윈 시즌 아이콘 (2026-10-13, 1.0.1 / versionCode 55)

할로윈 시즌 한정으로 런처 아이콘 + 스플래시 화면을 할로윈 테마로 교체.
앱 내 테마(크림/세이지 등 6종)는 건드리지 않음 — 아이콘/스플래시만 대상.

**적용한 것:**
- 기존 브랜드 캐릭터(전화 거는 말풍선 캐릭터)는 그대로 유지하고, 위에
  마녀 모자를 씌우고, 하트를 호박(잭오랜턴)으로 교체, 배경 빈 공간에
  작은 박쥐 실루엣 2개를 추가하는 방식으로 "리스킨"함 — 캐릭터 자체를
  새로 그리지 않아서 브랜드 일관성 유지하면서도 분명히 할로윈처럼 보임.
- 대상 파일: `drawable-nodpi/ic_launcher_art.png` (런처 아이콘 원본),
  `drawable-nodpi/splash_icon.png` (스플래시, 캐릭터 영역만 교체하고
  하단 "Hello, Today" 워드마크는 그대로 둠), `mipmap-*/ic_launcher.png`
  및 `ic_launcher_round.png` 전체 밀도(mdpi~xxxhdpi) — minSdk 26라
  실제로는 `mipmap-anydpi-v26`의 어댑티브 아이콘이 항상 쓰이지만,
  일관성을 위해 레거시 PNG들도 전부 같은 아트로 재생성함.
- 생성은 Pillow로 기존 PNG 위에 모자/호박/박쥐를 절차적으로 그려
  합성하는 방식 사용 (좌표는 원본 이미지에서 직접 픽셀 분석해서 추출).

**원본 백업 위치:** `hellotoday-app/app/halloween-2026/original-backup/`
— 할로윈 적용 전 원본 아이콘/스플래시 전체(위에 나열한 파일 전부)가
그대로 보관돼 있음.

### 할로윈 끝난 뒤 되돌리는 방법 (11월 초)

1. 백업된 파일들을 원래 경로로 복사해서 덮어쓰기:
   ```bash
   cd hellotoday-app/app
   cp halloween-2026/original-backup/ic_launcher_art.png src/main/res/drawable-nodpi/
   cp halloween-2026/original-backup/splash_icon.png src/main/res/drawable-nodpi/
   for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
     cp halloween-2026/original-backup/mipmap-$d/ic_launcher.png src/main/res/mipmap-$d/
     cp halloween-2026/original-backup/mipmap-$d/ic_launcher_round.png src/main/res/mipmap-$d/
   done
   ```
2. `build.gradle.kts`의 versionCode/versionName을 다음 번호로 올리기
   (예: 56 / 1.0.2)
3. 빌드 → 프로덕션에 업로드
4. 되돌린 뒤 `halloween-2026/` 폴더는 그대로 둬도 되고(내년 할로윈에
   재사용 가능), 지워도 무방함
