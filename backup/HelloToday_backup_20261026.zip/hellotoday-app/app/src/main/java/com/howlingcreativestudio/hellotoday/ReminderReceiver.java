package com.howlingcreativestudio.hellotoday;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent source) {
        String language = c.getSharedPreferences("hello_today_preferences", Context.MODE_PRIVATE).getString("language", "en");
        long personId = source.getLongExtra("personId", -1L);
        String name = source.getStringExtra("name");
        int interval = source.getIntExtra("interval", 7);
        int notifyHour = source.getIntExtra("notifyHour", 10);
        int notifyMinute = source.getIntExtra("notifyMinute", 0);
        String reminderMode = source.getStringExtra("reminderMode");
        int minDays = source.getIntExtra("minDays", 14);
        int maxDays = source.getIntExtra("maxDays", 28);
        boolean isTest = personId == ReminderScheduler.TEST_REMINDER_ID;
        // A dismissed/ignored notification used to just delete the pending
        // reminder record with nothing re-armed, so a person who never got
        // acted on fell silent forever -- the app's whole pitch is a
        // reminder that comes back, not a one-shot ping. Re-arm a same-time-
        // tomorrow follow-up instead (identical to the "내일 다시"/Tomorrow
        // action) so it keeps nagging daily until the user actually acts;
        // completing or snoozing from the notification/app overwrites this
        // pending alarm (same requestCode) the normal way, so there's no
        // double-notify once they do. Test reminders are exempt -- a
        // one-off connectivity check shouldn't turn into a recurring alarm.
        //
        // This native-side reschedule is invisible to the JS side unless
        // queued through NotificationActionStore the same way a tapped
        // "내일 다시" action is (see NotificationActionReceiver) -- otherwise
        // the alarm correctly re-fires tomorrow, but state.people[].nextAt in
        // index.html never advances, so the app keeps showing the old date
        // for that person even though a new notification is really coming.
        if (personId >= 0L && !isTest) {
            long nextAt = ReminderScheduler.snoozeOneDay(c, personId, name, interval, notifyHour, notifyMinute, reminderMode, minDays, maxDays);
            NotificationActionStore.add(c, "snooze", personId, System.currentTimeMillis(), nextAt);
        } else if (personId >= 0L) {
            ReminderScheduler.markDelivered(c, personId);
        }
        String channel = "gentle_reminders";
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nc = new NotificationChannel(channel, text(language, "Contact reminders", "連絡リマインダー", "연락 알림"), NotificationManager.IMPORTANCE_DEFAULT);
            nc.setDescription(text(language, "Reminders for people you want to contact", "連絡したい相手の通知", "등록한 사람의 연락 시기를 알려줍니다"));
            nm.createNotificationChannel(nc);
        }
        int notificationId = (int) (personId & 0x7fffffff);
        // getLaunchIntentForPackage() can return null in rare device states
        // (e.g. the launcher activity being disabled/mid-replace); falling
        // back to a plain launch-by-package-name intent keeps the
        // notification's tap action working instead of crashing this
        // receiver and losing the notification entirely.
        Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (open == null) open = new Intent(Intent.ACTION_MAIN).setPackage(c.getPackageName());
        open.putExtra("openPersonId", personId);
        PendingIntent pi = PendingIntent.getActivity(c, notificationId, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent complete = actionIntent(c, personId, name, interval, notifyHour, notifyMinute, reminderMode, minDays, maxDays, notificationId, "complete", notificationId + 100000);
        PendingIntent snooze = actionIntent(c, personId, name, interval, notifyHour, notifyMinute, reminderMode, minDays, maxDays, notificationId, "snooze", notificationId + 200000);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, channel) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_notification)
         .setContentTitle(isTest ? "Hello, Today · " + text(language, "Test reminder", "テスト通知", "테스트 알림") : "Hello, Today · " + (name == null || name.trim().isEmpty() ? text(language, "Contact reminder", "連絡リマインダー", "연락 알림") : name))
         .setContentText(isTest ? text(language, "Try the buttons below.", "下のボタンを試してください。", "아래 버튼을 눌러보세요.") : text(language, "Time to reach out.", "そろそろ連絡しませんか？", "연락할 때예요."))
         .setContentIntent(pi).setAutoCancel(true)
         .addAction(new Notification.Action.Builder(null, text(language, "I reached out", "連絡しました", "연락했어요"), complete).build())
         .addAction(new Notification.Action.Builder(null, text(language, "Tomorrow", "明日また", "내일 다시"), snooze).build());
        nm.notify(notificationId, b.build());
    }

    private String text(String language, String en, String ja, String ko) {
        return "ko".equals(language) ? ko : "ja".equals(language) ? ja : en;
    }

    private PendingIntent actionIntent(Context c, long personId, String name, int interval, int notifyHour, int notifyMinute, String reminderMode, int minDays, int maxDays, int notificationId, String action, int requestCode) {
        Intent i = new Intent(c, NotificationActionReceiver.class).putExtra("personId", personId).putExtra("name", name).putExtra("interval", interval).putExtra("notifyHour", notifyHour).putExtra("notifyMinute", notifyMinute).putExtra("reminderMode", reminderMode).putExtra("minDays", minDays).putExtra("maxDays", maxDays).putExtra("notificationId", notificationId).putExtra("actionType", action);
        return PendingIntent.getBroadcast(c, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
