import { useState, type ReactNode } from 'react';
import { Modal } from './Modal';
import { ConfirmDialog } from './ConfirmDialog';
import { BackupSheet } from './BackupSheet';
import { SetPinModal } from './SetPinModal';
import { HelpScreen } from './HelpScreen';
import { InfoScreen } from './InfoScreen';
import { FeedbackScreen } from './FeedbackScreen';
import { BackIcon } from './icons';
import { getNativeBridge } from '../lib/native';
import { isLockEnabled, removeLock } from '../lib/lock';
import type { AppData } from '../types';
import { useI18n, type Locale } from '../i18n';

interface SettingsProps {
  data: AppData;
  onImport: (data: AppData) => void;
  onMerge: (data: AppData) => void;
  onBack: () => void;
  bottomNav?: ReactNode;
}

const CONTACT_EMAIL = 'db5704@gmail.com';

// Flip this on once a real priced feature actually ships. The disclosure
// text below is scaffolded from Hello, Today's own 特定商取引法 page
// (same developer/business, so the seller-name and email fields are
// already correct as-is) since a paid feature is planned for later here
// too -- but the price/delivery-timing fields are necessarily placeholders
// until there's an actual in-app purchase to describe, and this is not a
// substitute for having it checked once real pricing exists. There's no
// language switcher in this app (unlike Hello, Today's ko/ja/en `l()`)
// for this to key off yet, hence the plain constant rather than a locale
// check -- wire it to a real language setting if/when this app gets one.
const SHOW_TOKUSHOHO = false;

function appVersion(): string {
  const native = getNativeBridge();
  return native?.appVersion?.() || __APP_VERSION__;
}

// A dedicated screen (not the old gear-icon-opens-a-modal shape) now that
// there's more here than just backup/restore -- reached from Home the
// same way GlobalSearch is, as Home-local state rather than its own
// App.tsx view, since it only ever needs what Home already has.
export function Settings({ data, onImport, onMerge, onBack, bottomNav }: SettingsProps) {
  const { t, locale, setLocale } = useI18n();
  const [showBackup, setShowBackup] = useState(false);
  const [showTokushoho, setShowTokushoho] = useState(false);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);
  const [lockEnabled, setLockEnabled] = useState(() => isLockEnabled());
  const [showSetPin, setShowSetPin] = useState(false);
  const [confirmRemoveLock, setConfirmRemoveLock] = useState(false);
  const [settingsView, setSettingsView] = useState<'main' | 'help' | 'info' | 'feedback'>('main');

  if (settingsView === 'help') {
    return <HelpScreen onBack={() => setSettingsView('main')} contactEmail={CONTACT_EMAIL} />;
  }

  if (settingsView === 'info') {
    return <InfoScreen onBack={() => setSettingsView('main')} version={appVersion()} />;
  }

  if (settingsView === 'feedback') {
    return <FeedbackScreen onBack={() => setSettingsView('main')} contactEmail={CONTACT_EMAIL} />;
  }

  return (
    <div className="screen settings-screen">
      <header className="app-header">
        <button type="button" className="icon-btn" onClick={onBack} aria-label={t('common.back')}>
          <BackIcon />
        </button>
        <h1>{t('settings.title')}</h1>
      </header>

      <div className={`screen-content ${bottomNav ? 'with-bottom-nav' : ''}`}>
        <div className="settings-row">
          <div className="settings-row-text">
            <b>{t('settingsExtra.backup')}</b>
            <span>{t('settingsExtra.backupDesc')}</span>
          </div>
          <button type="button" className="settings-row-btn" onClick={() => setShowBackup(true)}>
            {t('settingsExtra.manage')}
          </button>
        </div>

        <div className="settings-row">
          <div className="settings-row-text">
            <b>{t('settingsExtra.appLock')}</b>
            <span>{lockEnabled ? t('settingsExtra.locked') : t('settingsExtra.off')}</span>
          </div>
          <button
            type="button"
            className={`settings-row-btn ${lockEnabled ? 'danger' : ''}`}
            onClick={() => (lockEnabled ? setConfirmRemoveLock(true) : setShowSetPin(true))}
          >
            {lockEnabled ? t('settingsExtra.disable') : t('settingsExtra.enable')}
          </button>
        </div>

        <div className="settings-row">
          <div className="settings-row-text">
            <b>{t('settingsExtra.deleteAll')}</b>
            <span>{t('settingsExtra.deleteAllDesc')}</span>
          </div>
          <button type="button" className="settings-row-btn danger" onClick={() => setConfirmDeleteAll(true)}>
            {t('common.delete')}
          </button>
        </div>

        <div className="settings-row">
          <div className="settings-row-text">
            <b>{t('settingsExtra.contact')}</b>
            <span>{CONTACT_EMAIL}</span>
          </div>
          <a className="settings-row-btn" href={`mailto:${CONTACT_EMAIL}`}>
            {t('settingsExtra.email')}
          </a>
        </div>

        <div className="settings-row">
          <div className="settings-row-text">
            <b>{t('settings.help')}</b>
            <span>{t('helpScreen.guideTitle')}</span>
          </div>
          <button type="button" className="settings-row-btn" onClick={() => setSettingsView('help')}>
            {t('common.view')}
          </button>
        </div>

        <div className="settings-row">
          <div className="settings-row-text">
            <b>{t('settings.info')}</b>
            <span>{t('infoScreen.tagline')}</span>
          </div>
          <button type="button" className="settings-row-btn" onClick={() => setSettingsView('info')}>
            {t('common.view')}
          </button>
        </div>

        <div className="settings-row">
          <div className="settings-row-text">
            <b>{t('settings.feedback')}</b>
            <span>{t('feedbackScreen.promptBody')}</span>
          </div>
          <button type="button" className="settings-row-btn" onClick={() => setSettingsView('feedback')}>
            {t('common.view')}
          </button>
        </div>

        <div className="settings-row settings-language-row">
          <div className="settings-row-text">
            <b>{t('settings.language')}</b>
            <span>{t('language.subtitle')}</span>
          </div>
          <div className="settings-language-actions" role="group" aria-label={t('settings.language')}>
            {(['ko', 'ja', 'en'] as Locale[]).map((code) => (
              <button
                key={code}
                type="button"
                className={`settings-row-btn ${locale === code ? 'active' : ''}`}
                onClick={() => setLocale(code)}
                aria-pressed={locale === code}
              >
                {t(`language.${code}`)}
              </button>
            ))}
          </div>
        </div>

        {SHOW_TOKUSHOHO && (
          <div className="settings-row">
            <div className="settings-row-text">
              <b>特定商取引法に基づく表示</b>
              <span>{t('settingsExtra.commerceDesc')}</span>
            </div>
            <button type="button" className="settings-row-btn" onClick={() => setShowTokushoho(true)}>
              {t('common.view')}
            </button>
          </div>
        )}

        <p className="settings-version">{t('settingsExtra.version', { version: appVersion() })}</p>
      </div>

      {showBackup && (
        <BackupSheet data={data} onImport={onImport} onMerge={onMerge} onClose={() => setShowBackup(false)} />
      )}

      {showSetPin && (
        <SetPinModal
          onDone={() => {
            setLockEnabled(true);
            setShowSetPin(false);
          }}
          onClose={() => setShowSetPin(false)}
        />
      )}

      {confirmRemoveLock && (
        <ConfirmDialog
          title={t('settingsExtra.unlockTitle')}
          message={t('settingsExtra.unlockMessage')}
          confirmLabel={t('settingsExtra.disable')}
          danger
          onConfirm={() => {
            removeLock();
            setLockEnabled(false);
            setConfirmRemoveLock(false);
          }}
          onCancel={() => setConfirmRemoveLock(false)}
        />
      )}

      {confirmDeleteAll && (
        <ConfirmDialog
          title={t('settingsExtra.deleteAll')}
          message={t('settingsExtra.deleteAllMessage', { drawers: data.categories.length, items: data.entries.length })}
          confirmLabel={t('settingsExtra.deleteAllConfirm')}
          danger
          onConfirm={() => {
            onImport({ version: 1, categories: [], entries: [] });
            setConfirmDeleteAll(false);
          }}
          onCancel={() => setConfirmDeleteAll(false)}
        />
      )}

      {showTokushoho && (
        <Modal title="特定商取引法に基づく表示" onClose={() => setShowTokushoho(false)}>
          <p className="modal-hint">{t('settingsExtra.commerceIntro')}</p>
          <dl className="tokusho-list">
            <div className="tokusho-row">
              <dt>販売業者</dt>
              <dd>Howling Creative Studio（運営統括責任者：KIM EUN IL）</dd>
            </div>
            <div className="tokusho-row">
              <dt>所在地・電話番号</dt>
              <dd>ご請求をいただいた場合、遅滞なく開示いたします。下記メールアドレスまでご連絡ください。</dd>
            </div>
            <div className="tokusho-row">
              <dt>メールアドレス</dt>
              <dd>{CONTACT_EMAIL}</dd>
            </div>
            <div className="tokusho-row">
              <dt>販売価格</dt>
              <dd>未定（有料機能の提供開始時に表示します）</dd>
            </div>
            <div className="tokusho-row">
              <dt>商品代金以外の必要料金</dt>
              <dd>なし（通信料はお客様のご負担となります）</dd>
            </div>
            <div className="tokusho-row">
              <dt>お支払い方法・時期</dt>
              <dd>Google Playの決済システムにより、購入手続き完了時に即時決済されます。</dd>
            </div>
            <div className="tokusho-row">
              <dt>商品の提供時期</dt>
              <dd>決済完了後、直ちにアプリ内で該当機能が有効になります。</dd>
            </div>
            <div className="tokusho-row">
              <dt>返品・キャンセル</dt>
              <dd>
                デジタルコンテンツの性質上、購入手続き完了後の返品・返金は原則としてお受けできません。やむを得ない事情がある場合は上記メールアドレスまでご相談ください。
              </dd>
            </div>
            <div className="tokusho-row">
              <dt>動作環境</dt>
              <dd>Android 8.0（API 26）以上</dd>
            </div>
          </dl>
        </Modal>
      )}

      {bottomNav}
    </div>
  );
}
