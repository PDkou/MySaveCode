# Headless RunManager smoke test / balance probe.
# Run with: godot --headless --path game --script test_run.gd
extends SceneTree

func _initialize() -> void:
	var run := Node.new()
	run.set_script(load("res://scripts/RunManager.gd"))
	root.add_child(run)
	run.message.connect(func(t, k): print("[MSG:", k, "] ", t))
	run.state_changed.connect(func():
		print("[STATE] ", run.state, " round=", run.round_number,
			" food=", run.total_food, "/", run.quota,
			" attempts=", run.attempts_left, "/", run.attempts_per_round))

	run.start_run()
	var safety := 0
	while run.state != run.State.GAME_OVER and run.state != run.State.RETREATED and safety < 500:
		safety += 1
		match run.state:
			run.State.IDLE:
				run.start_attempt()
			run.State.DRAWING:
				if run.pot < 20 and randf() < 0.85:
					run.draw()
				else:
					run.cash_out()
			run.State.ROUND_CLEAR:
				if randf() < 0.3:
					run.retreat()
				else:
					run.continue_hunting()
			run.State.SHOP:
				if run.rerolls_left > 0 and randf() < 0.5:
					run.use_reroll()
				else:
					var offers: Array = run.offer_charms()
					print("[SHOP] offers=", offers.map(func(c): return "%s(%s)" % [c["id"], c["tier"]]))
					if offers.size() > 0:
						var pick: Dictionary = offers[randi() % offers.size()]
						run.pick_charm(pick["id"])
					else:
						run.skip_shop()

	var gm := root.get_node("GameManager")
	print("FINAL state=", run.state, " round=", run.round_number,
		" best_saved=", gm.best_round, " pelts=", gm.total_pelts, " safety_used=", safety)
	quit()
