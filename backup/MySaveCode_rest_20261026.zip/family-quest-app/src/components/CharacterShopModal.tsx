import { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

import { useAuth } from '../context/AuthContext';
import { useFamily } from '../context/FamilyContext';
import { CharacterSprite } from './CharacterSprite';
import { TitleFrame } from './TitleFrame';
import { ModalHeader } from './ModalHeader';
import { BADGE_ICON_SRC } from '../lib/gamification';
import {
  ShopActionError,
  equipItem,
  getEquippedItems,
  getOwnedItemIds,
  getShopItems,
  isHexColor,
  purchaseItem,
  shopItemDisplayName,
  unequipItem,
} from '../lib/shop';
import { useBackDismiss } from '../lib/backNav';
import type { BadgeKey, CharacterSlot, ShopItemRow } from '../types/database';

interface CharacterShopModalProps {
  onClose: () => void;
}

// title is deliberately not a shop tab -- titles are unlock-only (never
// purchasable) and are shown as an achievement gallery in MyStatsModal
// instead, alongside badges. This modal still fetches title items (see
// equippedTitleName below) purely to show which one is currently equipped
// next to the character preview.
const SLOTS: CharacterSlot[] = ['body', 'top', 'pants', 'shoes', 'head', 'weapon', 'shield', 'accessory1', 'accessory2', 'background'];

export function CharacterShopModal({ onClose }: CharacterShopModalProps) {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const { family, members, refresh: refreshFamily } = useFamily();
  useBackDismiss(true, onClose);

  const [items, setItems] = useState<ShopItemRow[]>([]);
  const [ownedIds, setOwnedIds] = useState<Set<string>>(new Set());
  const [equippedBySlot, setEquippedBySlot] = useState<Map<CharacterSlot, string>>(new Map());
  const [activeSlot, setActiveSlot] = useState<CharacterSlot>('body');
  const [loading, setLoading] = useState(true);
  const [busyItemId, setBusyItemId] = useState<string | null>(null);
  const [errorKey, setErrorKey] = useState<string | null>(null);

  const me = user ? members.find((m) => m.user_id === user.id) : undefined;
  const myBalance = me?.points ?? 0;
  const equippedBadgeKey = (me?.equipped_badge_key as BadgeKey | null) ?? null;

  // Guards overlapping load() calls (mount effect + every purchase/equip
  // handler below) from landing out of order -- a quick double-tap on two
  // different items before the first request resolves could otherwise let
  // the slower response win and show a stale owned/equipped state, same
  // class of race as FamilyContext.load() had (2026-08 bug report).
  const loadSeqRef = useRef(0);

  // `silent` skips the loading gate that swaps the whole item list out for
  // "불러오는 중..." -- right for the very first load, but handlePurchase/
  // handleEquip also call load() to pick up the item's new owned/equipped
  // state, and re-showing that gate on every purchase/equip flashed the
  // entire list out and back in for no reason.
  const load = async (options?: { silent?: boolean }) => {
    if (!user || !family) return;
    const silent = options?.silent ?? false;
    const mySeq = ++loadSeqRef.current;
    if (!silent) setLoading(true);
    const [shopItems, owned, equipped] = await Promise.all([
      getShopItems(),
      getOwnedItemIds(user.id, family.id),
      getEquippedItems(user.id, family.id),
    ]);
    if (loadSeqRef.current !== mySeq) return;
    setItems(shopItems);
    setOwnedIds(owned);
    setEquippedBySlot(new Map(equipped.map((e) => [e.slot, e.item_id])));
    if (!silent) setLoading(false);
  };

  // Keyed on the ids, not the family/user objects themselves -- see the
  // matching comment in MyStatsModal.tsx: FamilyContext.load() mints a new
  // family object on every refresh (including silent ones from unrelated
  // actions elsewhere, e.g. equipping a badge), and depending on the object
  // here would re-run this effect and flash the whole item list to
  // "불러오는 중..." on every one of those.
  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, family?.id]);

  const itemsById = useMemo(() => new Map(items.map((i) => [i.id, i])), [items]);
  const spritePreview = useMemo(() => {
    const preview: Partial<Record<CharacterSlot, string>> = {};
    for (const [slot, itemId] of equippedBySlot) {
      if (slot === 'title') continue; // text label, not a visual sprite -- shown separately below
      const item = itemsById.get(itemId);
      if (item?.sprite_key) preview[slot] = item.sprite_key;
    }
    return preview;
  }, [equippedBySlot, itemsById]);
  const equippedTitleItem = useMemo(() => {
    const titleItemId = equippedBySlot.get('title');
    return titleItemId ? itemsById.get(titleItemId) ?? null : null;
  }, [equippedBySlot, itemsById]);
  const equippedTitleName = equippedTitleItem ? shopItemDisplayName(equippedTitleItem, i18n.language) : null;

  // Fully-hidden titles (GAMIFICATION_DESIGN.md section 8's "완전 히든 칭호")
  // shouldn't even reveal their existence -- not shown as a locked row --
  // until the owning condition actually grants them.
  const slotItems = items.filter((i) => i.slot === activeSlot && (!i.hidden || ownedIds.has(i.id)));

  const handlePurchase = async (item: ShopItemRow) => {
    if (!family) return;
    setErrorKey(null);
    setBusyItemId(item.id);
    try {
      await purchaseItem(family.id, item.id);
      await Promise.all([load({ silent: true }), refreshFamily()]);
    } catch (err) {
      setErrorKey(err instanceof ShopActionError ? err.translationKey : 'shop.error.unknown');
    } finally {
      setBusyItemId(null);
    }
  };

  const handleEquip = async (item: ShopItemRow) => {
    if (!family) return;
    setErrorKey(null);
    setBusyItemId(item.id);
    try {
      const alreadyEquipped = equippedBySlot.get(item.slot) === item.id;
      if (alreadyEquipped) {
        await unequipItem(family.id, item.slot);
      } else {
        await equipItem(family.id, item.id);
      }
      await load({ silent: true });
    } catch (err) {
      setErrorKey(err instanceof ShopActionError ? err.translationKey : 'shop.error.unknown');
    } finally {
      setBusyItemId(null);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <ModalHeader title={t('shop.heading')} onClose={onClose} />

        <div className="shop-preview-row">
          <CharacterSprite equipped={spritePreview} size={96} />
          <div className="shop-preview-info">
            <span className="shop-balance">
              <img className="shop-balance-icon" src="/currency/points.png" alt="" aria-hidden="true" />
              {t('shop.balance', { balance: myBalance })}
            </span>
            {/* Badge and title are independently equipped from different
                galleries, but when both are set they render as one
                nameplate -- the badge sits inside the title's frame rather
                than as a second disconnected chip (2026-08-01 feedback).
                A badge with no title equipped still gets its own round
                icon slot below. */}
            <div className="shop-equipped-badges">
              {equippedTitleName ? (
                <TitleFrame
                  tier={equippedTitleItem?.tier ?? null}
                  badgeSrc={equippedBadgeKey ? BADGE_ICON_SRC[equippedBadgeKey] : undefined}
                >
                  {equippedTitleName}
                </TitleFrame>
              ) : (
                equippedBadgeKey && (
                  <span className="badge-chip">
                    <img className="badge-chip-icon" src={BADGE_ICON_SRC[equippedBadgeKey]} alt="" aria-hidden="true" />
                    {t(`badges.${equippedBadgeKey}.name`)}
                  </span>
                )
              )}
            </div>
          </div>
        </div>

        <div className="shop-slot-tabs">
          {SLOTS.map((slot) => (
            <button
              key={slot}
              type="button"
              className={`shop-slot-tab ${activeSlot === slot ? 'shop-slot-tab-active' : ''}`}
              onClick={() => setActiveSlot(slot)}
            >
              {t(`shop.slot.${slot}`)}
            </button>
          ))}
        </div>

        {errorKey && <p className="form-error" role="alert">{t(errorKey)}</p>}

        {loading ? (
          <p className="empty-message">{t('common.loading')}</p>
        ) : slotItems.length === 0 ? (
          <p className="empty-message">{t('shop.emptySlot')}</p>
        ) : (
          <div className="shop-item-list">
            {slotItems.map((item) => {
              const owned = ownedIds.has(item.id);
              const equipped = equippedBySlot.get(item.slot) === item.id;
              const affordable = item.price !== null && myBalance >= item.price;
              const busy = busyItemId === item.id;
              return (
                <div key={item.id} className={`shop-item-row ${equipped ? 'shop-item-row-equipped' : ''}`}>
                  <span
                    className="shop-item-sprite"
                    style={item.sprite_key && isHexColor(item.sprite_key) ? { backgroundColor: item.sprite_key } : undefined}
                  >
                    {item.sprite_key && isHexColor(item.sprite_key) ? '' : item.sprite_key || '·'}
                    {owned && <img className="shop-item-owned-badge" src="/shop/owned-check.png" alt="" aria-hidden="true" />}
                  </span>
                  <span className="shop-item-name">{item.name}</span>
                  {owned ? (
                    <button
                      type="button"
                      className={`shop-action-btn ${equipped ? 'shop-action-btn-unequip' : 'shop-action-btn-equip'}`}
                      disabled={busy}
                      onClick={() => void handleEquip(item)}
                    >
                      {equipped ? t('shop.unequip') : t('shop.equip')}
                    </button>
                  ) : item.acquisition_type === 'title_condition' ? (
                    <span className="shop-item-locked">
                      <img className="shop-item-locked-icon" src="/shop/locked.png" alt="" aria-hidden="true" />
                      {t('shop.lockedLabel')}
                    </span>
                  ) : item.currency === 'tycoon' ? (
                    // 'tycoon' is a legacy currency key name (the personal
                    // tycoon it originally referred to is gone -- see
                    // schema.sql section 35) -- these items are now bought
                    // with the housework clicker's currency, from a small
                    // shop section inside HouseworkClickerModal's meta
                    // sheet. This points shop still lists them here too so
                    // they can be equipped once owned.
                    <span className="shop-item-locked">{t('shop.buyInTycoonShop')}</span>
                  ) : (
                    <button
                      type="button"
                      className="shop-action-btn shop-action-btn-buy"
                      disabled={busy || !affordable}
                      onClick={() => void handlePurchase(item)}
                    >
                      {t('shop.purchase', { price: item.price })}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <div className="modal-actions">
          <button type="button" className="btn btn-primary btn-block" onClick={onClose}>
            {t('common.close')}
          </button>
        </div>
      </div>
    </div>
  );
}
