# 집안일 클리커 아트 에셋 인수인계 문서 v2 (GPT/이미지 생성 도구용)

> **⚠️ 2026-08 상태 메모**: 이 v2가 요청한 도트 픽셀아트 렌더링 방향은 이후 v7에서 "플랫
> 일러스트"로, v8(`CLEANER_ART_REDO_HANDOFF.md`)에서 다시 "부위별 리깅"으로 바뀌었습니다 --
> **스타일 스펙만 놓고 보면 이 문서는 낡았습니다.** 다만 `public/art/cleaner/`를 실제로
> 확인해보면 캐릭터 포즈/방 배경/도구 아이콘 에셋 자체는 이미 만들어져서
> `HouseworkClickerModal.tsx`에 연결까지 되어 있습니다(자세한 건 각 후속 문서의 동일한 메모
> 참고) -- 다만 v8이 요청한 "리깅" 방식이 아니라 여전히 포즈별 개별 이미지 방식으로 보입니다.
> 새로 작업을 시작하기 전에 `CLEANER_ART_REDO_HANDOFF.md`부터 먼저 읽으세요.

v1 문서는 방향을 잘못 잡았습니다 — 기존 온보딩 마스코트를 재사용하는 쪽으로 갔었는데,
**이번 v2는 완전히 새로운 클리커 전용 캐릭터 한 쌍(여자/남자)을 처음부터 새로 그리는
방향**으로 다시 씁니다. 기존 마스코트/구 타이쿤 NPC는 스타일 참고로도 인용하지 않습니다
— 아래 기술 스펙(투명 배경, 픽셀아트 렌더링 등)만 지키면 비주얼 방향은 새로 잡아도
됩니다.

**주의**: 원본 스펙 문서(`FAMILY_QUEST_CLICKER_HANDOFF.md`)에 있던 캐릭터 디자인 원문
문구는 지금 이 대화에 남아있지 않습니다. 그 문서에 적었던 캐릭터 설명을 그대로 따르고
싶으면 그 문서를 다시 첨부해주세요 — 그러면 그 문구를 8번 프롬프트에 그대로 반영합니다.
지금 이 문서의 7번/8번은 그 원문 없이 일반적인 방향으로 작성한 것입니다.

## 1. 앱이 뭔지 (3줄 요약)

"Family Quest"는 가족(또는 회사팀/개인)이 집안일·할 일을 "퀘스트"로 서로 의뢰하고
완료하는 React+Supabase PWA입니다. 그 안에 곁들여진 개인 미니게임이 "집안일 클리커"로,
화면 속 "집안일하기" 버튼을 눌러 청소 포인트를 모으고, 그 포인트로 자동 청소 도구를 사서
방을 단계별로 깨끗하게 만드는 방치형 클리커입니다.

## 2. 지금 상태 — 왜 다시 쓰는가

클리커 화면(`HouseworkClickerModal.tsx`)의 캐릭터는 지금 온보딩 튜토리얼용 토끼 마스코트
이미지 2장을 임시로 갖다 쓰고 있고, 애니메이션도 정지 이미지 1장(대기) + 정지 이미지 1장
(탭 반응)을 CSS로 흔드는 수준입니다. 실제로 청소하는 동작, 단계 완료, 대청소, 새 도구
발견, 환생 같은 주요 순간에 대한 전용 그림이 전혀 없습니다. 이번 v2 목표는:

1. **기존 것을 재사용하지 않는 완전히 새로운 캐릭터 한 쌍**(여자/남자, 유저가 선택)
2. **포즈를 2개가 아니라 7개**로 늘려서 실제로 "청소하는 느낌"이 나게

## 3. 통합 지점 (참고용 — 지금 당장 코드가 이렇게 바뀐다는 뜻은 아님)

지금 코드 상태(`src/components/HouseworkClickerModal.tsx`)는 포즈가 2개(대기/탭)뿐이라,
7포즈를 실제로 붙이려면 **아트가 나온 다음 단계에서 코드 작업도 추가로 필요**합니다(이
문서는 그 전 단계인 아트 제작용입니다). 참고로 각 포즈가 코드의 어느 신호에 연결될
예정인지 미리 적어둡니다 — 이미 서버(RPC) 쪽에는 아래 신호들이 전부 존재하므로, 아트만
준비되면 UI 쪽 분기 추가는 크지 않은 작업입니다:

| 포즈 | 트리거 예정 |
|---|---|
| 대기 | 기본 상태, 아무 입력 없을 때 |
| 빗자루질 연속 동작 | "집안일하기" 버튼을 누르고 있는 동안 |
| 걸레질 연속 동작 | 빗자루질과 교차 사용(탭마다 랜덤 교차 또는 방 종류별 구분 — 아직 미정, 열린 결정) |
| 단계 완료 | `complete_cleaner_stage` 성공 + `is_deep_clean = false` |
| 대청소 | `complete_cleaner_stage` 성공 + `is_deep_clean = true` (5단계마다) |
| 새 도구 발견 | `buy_cleaner_tool` 최초 구매 성공 시 |
| 환생 | `perform_cleaner_prestige` 성공 시 |

캐릭터 선택(성별 고르는 UI, 저장 방식)도 아직 코드에 없고, 아트가 나온 뒤 붙일 후속
작업입니다.

**바뀌지 않는 것**: DB 스키마, RPC, 배치/하트비트 로직, 탭 판정 — 이것들은 캐릭터 아트와
무관하게 이미 동작합니다.

## 4. 필요한 아트 — 캐릭터 2종 × 포즈 7개

| # | 포즈 | 설명 / 동작 |
|---|---|---|
| 1 | 대기 | 가만히 서 있는 기본 포즈. 정적 이미지 1장 (미세한 위아래 움직임은 CSS로 별도 처리) |
| 2 | 빗자루질 | 빗자루로 바닥을 쓰는 연속 동작. **2~3프레임 스프라이트시트 권장**(진짜 움직이는 느낌을 원하면) — 최소 1장(정지 포즈 + CSS 스쿼시)도 가능 |
| 3 | 걸레질 | 걸레로 바닥/표면을 닦는 연속 동작. 빗자루질과 동일하게 2~3프레임 권장, 최소 1장 가능 |
| 4 | 단계 완료 | 작은 성취 리액션(엄지척, 이마 땀 닦기 등). 정지 이미지 1장 |
| 5 | 대청소 | 방 하나를 통째로 끝냈을 때 나오는 더 큰 축하 포즈(양팔 들고 환호 등). 정지 이미지 1장 |
| 6 | 새 도구 발견 | 새 청소도구를 손에 들고 놀라워하는 포즈. 정지 이미지 1장 |
| 7 | 환생 | 반짝별을 얻는 특별 연출 포즈(빛나는 이펙트와 잘 어울리는 자세). 정지 이미지 1장 |

캐릭터가 2종(여자/남자)이므로 **최소 14장**(포즈당 1장씩 × 2캐릭터), 빗자루질/걸레질을
멀티프레임으로 하면 최대 18~22장 정도입니다. 한 번에 다 안 나와도 됩니다 — 1(대기) +
2(탭 반응 역할, 지금은 빗자루질로 대체) 두 장만 먼저 나와도 지금 코드에 바로 꽂아볼 수
있습니다.

### 4-1. 룸 배경 — 여전히 선택 사항이지만 우선순위 상향

5개 방(`living_room`/`kitchen`/`bathroom`/`kids_room`/`whole_house`)이 있고 지금은 CSS
그라디언트 색조로만 구분됩니다(아래 팔레트 참고). 단계가 올라갈수록(1→5) 방이 실제로
더 깨끗해 보이는 배경 아트가 있으면 좋겠지만, 방 5개 × 단계 5개 = 25장이 되므로 이번
라운드는 **방 5개당 "더러움"/"깨끗함" 2장씩(10장)** 정도로 축소해서 시작하는 걸
추천합니다. 필수는 아니지만 캐릭터 다음 우선순위로 둡니다.

### 4-2. 청소 도구 아이콘 — 선택

도구 8종(장난감 정리함/먼지떨이/자동 빗자루/로봇청소기/자동 대걸레/식기세척기/세탁
도우미/헬퍼 로봇) 각각의 작은 정사각형 아이콘. 상점 카드에 붙이는 용도, 여전히 선택
사항입니다.

## 5. 스타일 가이드

- **픽셀아트여야 함(기술적 제약, 취향 문제 아님)**: 씬 컨테이너에 CSS
  `image-rendering: pixelated`가 걸려 있어서, 고해상도 매끈한 일러스트를 넣으면 확대될 때
  계단 현상이 어색하게 보입니다. 저해상도로 그려서 그대로 올리는 진짜 픽셀아트여야 합니다.
  (이 CSS 속성 자체를 빼고 싶다면 — 예를 들어 벡터/플랫 일러스트 스타일로 완전히 바꾸고
  싶다면 — 그건 별도로 알려주세요, 코드에서 뺄 수 있습니다.)
- 두꺼운 다크 아웃라인 + 채도 높은 플랫 셀 음영을 권장합니다(부드러운 그라디언트/노이즈/
  일반적인 AI풍 음영은 이 앱 다른 그림들과 안 어울립니다).
- 두 캐릭터(여자/남자)는 **같은 세트로 보이도록** 체형 비율/아웃라인 두께/전체 톤을
  맞추고, 팔레트만 구분되게 그려주세요.

### 5-1. "AI스러운 도트아트" 피하기 (중요 — 실제로 발견된 문제)

기존에 나온 캐릭터 아트(`cleaner-girl-idle.png` 등)를 픽셀 단위로 분석해보니
색상이 255가지나 쓰여 있었습니다 — 진짜 도트아트는 이 크기 캐릭터면 보통
12~32색 정도로 딱 정해놓고 그립니다. 원인은 "픽셀아트 스타일"이라는 프롬프트
단어만으로는 실제 저해상도 격자에 그려주는 게 아니라, 고해상도로 부드럽게
렌더링한 다음 픽셀처럼 보이게 필터만 씌우기 때문입니다. 이번엔 아래 조건을
프롬프트에 반드시 포함해주세요 (8번 프롬프트에 이미 반영했습니다):

- **실제 캔버스 자체를 저해상도로 생성**: "실제 렌더링 해상도 자체를 64~96픽셀
  정도로, 그 이상 디테일을 넣지 말고" 처럼 네이티브 저해상도를 명시. 고해상도로
  그린 다음 축소하는 게 아니라, 애초에 낮은 해상도 격자 위에 그려야 함.
  결과물을 확대해서 전달해야 한다면 **최근접 이웃(nearest-neighbor) 방식으로만
  확대** — AI/스무스 업스케일은 각진 픽셀 경계를 뭉갬.
- **팔레트를 숫자로 못박기**: 전체 스프라이트 기준 16~20색 이내, 부위(피부/머리/
  옷)마다 밝은 톤 1개 + 그림자 톤 1개(최대 하이라이트 톤 1개 추가), 그 이상
  단계적 그라디언트 금지.
- **아웃라인 두께 전체 통일**: 이미지 전체에서 테두리가 항상 같은 픽셀 두께.
- **경계에 반투명 픽셀 없음**: 알파값은 완전 불투명 아니면 완전 투명 둘 중
  하나만 — 안티에일리어싱/디더링 노이즈 있는 부드러운 경계 금지.
- 가능하면 범용 이미지 생성 AI(달리/미드저니/GPT 이미지 등)보다 **도트아트
  전용 생성 도구**(예: Retro Diffusion류 픽셀아트 특화 모델)를 우선 시도해주세요
  — 범용 디퓨전 모델은 구조적으로 진짜 격자/팔레트 제약을 걸지 못해서 위
  조건들을 지시해도 완벽히 지켜지지 않는 경우가 많습니다.

**룸 배경 팔레트** (지금 CSS 그라디언트 값 — 배경 아트를 그린다면 톤 참고용):

| 방 | 주요 색 (밝은순) |
|---|---|
| 거실(기본) | `#8fcbe8` → `#78b9df` → `#5a9dc4` (하늘색 계열) |
| 주방 | `#a3d1a8` → `#7fbf8e` → `#5c9e72` (연두 계열) |
| 욕실 | `#8fd8d1` → `#63b9b1` → `#468f89` (민트/청록 계열) |
| 아이방 | `#e8a8d8` → `#d17fc0` → `#a95c9c` (핑크/보라 계열) |
| 집 전체 | `#f0c988` → `#e6a94f` → `#c9822f` (황금빛 계열) |

## 6. 파일 스펙

- 포맷: PNG, 투명 배경(alpha 채널)
- 세로 640px 기준 권장 (가로는 포즈에 맞게 자유)
- 화면에서는 정사각형 씬 컨테이너 안에 가로폭 44%(최대 220px)로 하단 중앙 정렬되어
  들어갑니다 — 캐릭터 전신이 보이는 정면/살짝 정면-측면 구도를 권장
- 스프라이트시트로 그리는 경우(빗자루질/걸레질) 프레임을 가로로 균등 폭으로 나란히
  배치해주세요(기존 `npc-craft-worker-hammer.png` 같은 4프레임 가로 시트 형식 — 이건
  파일 포맷 참고이지 그 그림 자체를 스타일 기준으로 쓰라는 뜻은 아닙니다)

## 7. 캐릭터 컨셉 방향 (원본 스펙 문서 원문이 없어서 일반 방향으로 작성)

가족 전연령 톤(폭력/전투 요소 없음)의 귀엽고 통통한 실루엣, 청소 도구(빗자루/걸레/
먼지떨이)와 잘 어울리는 큰 눈/과장된 표정의 캐릭터를 추천합니다. 여자/남자 캐릭터는 서로
짝처럼 보이되(같은 체형 비율, 같은 아웃라인 두께) 팔레트로 구분(예: 한쪽은 웜톤 계열,
다른 쪽은 쿨톤 계열)하면 좋습니다.

**원본 핸드오프 문서에 이미 구체적인 캐릭터 디자인 설명이 있었다면, 그 문서를 다시
보내주세요 — 이 섹션과 8번 프롬프트를 그 원문 그대로 다시 씁니다.**

## 8. 바로 쓸 수 있는 이미지 생성 프롬프트 (초안, 여자 캐릭터 기준)

대기 포즈:

```
Brand-new chibi pixel art character design for a mobile housework-cleaning
clicker game, cute girl character, original design (not based on any
existing mascot). Render at a genuinely low native resolution (actual
canvas around 64-96 pixels tall, not a high-resolution illustration
styled to look pixelated) with a strict locked color palette of 16-20
colors total for the whole sprite -- each surface (skin/hair/clothes)
shaded with exactly one base tone plus one shadow tone (at most one extra
highlight tone), no soft gradients, no airbrush shading, no
photorealistic texture. Thick dark brown outline of perfectly uniform
pixel width throughout. Large expressive eyes, oversized head-to-body
ratio, short chunky limbs, warm kid-friendly palette, standing idle pose,
holding a broom loosely at her side, fully transparent background with
hard binary alpha (no semi-transparent/anti-aliased edge pixels),
front-facing three-quarter pose, chunky low-resolution pixel blocks (not
smooth/anti-aliased), full body visible head to feet, no shadow baked
into the image. If upscaling for delivery, upscale with nearest-neighbor
only, never AI/smooth upscaling. Avoid: realistic rendering, soft
AI-diffusion shading, noise texture, dithering, muted/desaturated colors,
painterly brushwork, gradient blending.
```

빗자루질 포즈(2~3프레임 스프라이트시트로 요청):

```
Same character as above (same native low resolution, same locked 16-20
color palette, same uniform outline width, same hard binary alpha), 3-frame
side-scrolling sprite sheet of a sweeping motion with a broom (frame 1:
broom pulled back, frame 2: broom mid-sweep, frame 3: broom
follow-through), frames arranged horizontally in equal width cells,
transparent background, chunky pixel art, no anti-aliasing, no soft
gradients, nearest-neighbor upscale only if delivered larger than native
resolution.
```

다른 5개 포즈(걸레질/단계완료/대청소/새도구발견/환생)도 "같은 캐릭터, 같은 스타일"이라고
명시하면서 포즈 설명만 바꿔 순서대로 요청하면 한 세트로 일관되게 나올 확률이 높습니다.
남자 캐릭터는 위 프롬프트에서 `cute girl character`를 `cute boy character`로, 톤을
다른 팔레트 계열로 바꿔서 똑같이 7포즈 요청하면 됩니다.

## 9. 구현 검증용 자료

지피티가 실제 구현 상태(도구 숨김/오프라인 자동수익 정지/6단계 진행/환생 계산/기존
타이쿤 데이터 전환)를 확인하고 싶어해서, 이 문서와 함께 `family-quest-app` 소스 전체를
담은 zip을 별도로 첨부합니다(`git archive` 기준 — 커밋된 파일만 포함, `node_modules`/
`.env`/빌드 산출물 제외).

**업데이트**: 지피티가 v1 zip 검토에서 지적한 5개 치명적 버그(환생 무한 반복,
quick_living_room 진행 불능, 오프라인 수익 누출, 환생/칭호 한 단계 일찍 열림, RLS 범위
과다) + 8개 부가 문제(업그레이드 선행조건 트리, 배지 등록/캡, 자동화 칭호 조건, 칭호
일본어명, 큰 수 교환 정밀도, 초당 생산량 표시, 탭 배치 flush, 키보드 접근성)를 전부
로컬 Postgres에서 `authenticated` 롤로 재현·검증 후 수정해서 이번 zip에 반영했습니다.

**업데이트 2**: 지피티가 뽑아준 실제 아트(캐릭터/방 배경/클러터/로봇청소기)를 검토 후
그대로 통합했습니다 — 캐릭터 대기+빗자루질(4프레임), 방 5개 배경, 클러터 오버레이 4종,
로봇청소기 씬 스프라이트가 전부 화면에 반영되어 있습니다. 남아있는 건 걸레질/단계완료/
대청소/새도구발견/환생 포즈, 남자 캐릭터뿐입니다.
