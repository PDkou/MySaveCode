# Family Quest

가족(또는 개인/회사팀)이 실제로 쓰는 생활 퀘스트 공유 앱. React + Vite + TypeScript + Supabase 기반
PWA. **기능 전체를 한눈에 훑어보려면 `FEATURES.md`**를 먼저 보세요 (지금 라이브인지/코드는
있는데 꺼져있는지/설정 대기인지 상태까지 표시되어 있음). 설계 배경과 전체 구현 이력은
`GAMIFICATION_DESIGN.md`(게임화 시스템)를 참고하세요 — 이 문서는 설치/배포/테스트 절차 중심입니다.
실제 이미지/아이콘 제작이 필요한 영역은 `design/`(캐릭터 아트, 뱃지·칭호 아이콘, 앱 브랜딩, UI
비주얼)을 참고하세요.

### 기본 기능
- 이메일/비밀번호 회원가입·로그인 (비밀번호 찾기 포함)
- 방 생성(8자리 초대 코드, QR 코드로도 공유 가능) / 참여, 인원 제한 없음, 한 계정으로 여러 방 참여
  가능 (우리 가족/친정/시댁/회사팀 등). 방 종류는 **개인방**(혼자 쓰는 할 일 관리, 의뢰금 없이 무료)
  / **가족방** / **회사방**(CSV 리포트 내보내기 가능) 3종
- 퀘스트(할 일) 등록 → 담당자 지정(특정인/전원/선착순 중 자동 판별) → 완료 처리(결과 메모) → 필요 시
  재오픈. 기한과 별도로 시작일도 지정 가능(시작 전엔 "예정" 상태), 반복(매일/매주 요일 지정/매월)
  설정 가능
- 처리 기록(누가 등록/완료/재오픈했는지) 자동 기록, 완료 건에 댓글(진행 메모/완료 반응) 작성
- 자주 쓰는 의뢰 내용(담당자 포함) 저장 후 드롭다운으로 빠르게 재등록, 담당자 제비뽑기, 퀘스트
  검색/핀 고정/일괄 선택-완료, 캘린더 뷰, 완료 사진 모아보기(사진첩)

### 게임화 (자세한 설계는 `GAMIFICATION_DESIGN.md` 참고)
- 공유 방(2인 이상)의 퀘스트는 의뢰금(등록 시 거는 골드, 최소 5골드)을 걸고, 완료하면 포상금으로
  받음 — 완료자 전액 + 의뢰자에게 소액 환급 보너스. 레벨이 오를수록 필요 경험치도 늘어나는 성장형
  레벨/경험치, 연속 완료 스트릭, 조건 달성형 뱃지, 80여 종 칭호(테마별 탭으로 구분) 수집
- 완료 시 컨페티 애니메이션 + 랜덤 축하 메시지, 대시보드 헤더에 경험치 진행 바 + 보유 골드 상시 표시
- 이번 주 가족별 완료 현황(주간 리포트, MVP 하이라이트)
- **캐릭터 커스터마이징**(골드로 꾸미기, 11개 슬롯)과 **청소 미니게임**(방치형 클리커)은 코드/DB
  전부 구현되어 있지만, 비주얼 아트 방향이 아직 안 정해져서 **현재 UI에서는 꺼져있는 상태**입니다
  (`src/lib/featureFlags.ts`에서 플래그 하나로 관리 -- 다시 켜면 바로 복귀). `FEATURES.md` 7번
  참고.

### 알림 / 편의 기능
- 기기 푸시 알림: 마감 임박, 담당 배정, 완료, 댓글, 마감 초과(에스컬레이션), 주간 요약 — 종류별로 켜고 끌 수 있음
- 앱 내 알림 벨(읽음 처리), 앱 아이콘 배지(내 담당 미완료 건수)
- 자주 쓰는 의뢰 템플릿, 앱 내 도움말, 홈 화면 설치 유도 배너
- 라이트/다크 모드 + 5가지 색상 테마(퍼플/핑크/블루/그린/오렌지)
- 프로필 사진 업로드(드래그/줌 크롭 포함), 방 이름 변경, 초대 코드 재발급, 멤버 내보내기/탈퇴
- 한국어/일본어: 기기 언어 자동 감지 + 수동 전환, 선택한 언어는 프로필에도 저장
- 홈 화면 설치 가능한 PWA (Android Chrome, iPhone Safari)
- 방 데이터는 Supabase Row Level Security로 완전히 분리

## 기술 스택

- React 19 + TypeScript + Vite 8
- React Router (화면 전환)
- Supabase JS (`@supabase/supabase-js`) — Auth, Postgres, Realtime
- i18next / react-i18next (+ 브라우저 언어 자동 감지)
- vite-plugin-pwa (manifest + service worker)
- 순수 CSS (프레임워크 없음), 모바일 우선 반응형

## 프로젝트 구조

```
family-quest-app/
  index.html
  vite.config.ts              # vite-plugin-pwa 설정 포함
  ART_HANDOFF.md               # 캐릭터 아트 에셋 제작 인수인계 문서 (placeholder → 실제 이미지 교체용)
  GAMIFICATION_DESIGN.md       # 게임화 시스템 설계 + 전체 구현 이력(Phase 1~N, 시간순)
  supabase/
    schema.sql                 # 테이블/함수/트리거/RLS 전체 (한 번에 실행, 재실행해도 안전)
    functions/
      send-due-reminders/      # 기기 푸시 알림 Edge Function (마감/배정/완료/댓글/에스컬레이션/주간요약)
  src/
    main.tsx
    App.tsx                    # 라우팅 + Provider 조립
    i18n/index.ts               # i18next 초기화, 언어 감지 설정
    locales/{ko,ja}.json        # 전체 UI 문구
    lib/
      supabaseClient.ts         # Supabase 클라이언트 (publishable key만 사용)
      formatDate.ts / lastRoute.ts
      gamification.ts           # 레벨/경험치/뱃지 계산 (순수 함수, DB엔 raw points만 저장)
      shop.ts                   # 상점 아이템 조회/장착 상태 + 칭호 다국어 표시명 헬퍼
      tycoon.ts                 # 방치형 타이쿤 계산
      questRules.ts             # 배정 방식 판별 등 퀘스트 관련 순수 로직
      colorTheme.ts / theme.ts  # 색상 테마 / 라이트·다크 모드
      pushNotifications.ts      # 기기 푸시 구독 등록/해제
      avatarPhotos.ts / taskPhotos.ts  # 프로필/완료 사진 업로드
    types/database.ts           # 테이블/RPC 타입 (supabase-js 제네릭용)
    context/
      AuthContext.tsx           # 세션, 회원가입/로그인/로그아웃, 언어 저장
      FamilyContext.tsx         # 방 조회/생성/참여, 여러 방 전환
      TasksContext.tsx          # 퀘스트 목록 + realtime 구독
    hooks/
      useTaskDetail.ts          # 퀘스트 상세 + 처리 기록 + realtime 구독
      useNotifications.ts       # 알림 목록 + 읽음 처리
    pages/
      AuthPage.tsx / ResetPasswordPage.tsx
      FamilySetupPage.tsx
      DashboardPage.tsx         # 헤더(캐릭터/경험치바/골드/아이콘) + 퀘스트 목록 + 필터
      TaskDetailPage.tsx
      CalendarPage.tsx / PhotoGalleryPage.tsx / HelpPage.tsx
    components/                 # 모달/카드/입력 컴포넌트 30여 개 — 대표적으로
      TaskCard.tsx / NewTaskModal.tsx / TaskTemplatePicker.tsx
      MyStatsModal.tsx          # 레벨/경험치/뱃지/칭호(테마별 탭) 컬렉션
      CharacterShopModal.tsx / CharacterSprite.tsx  # 캐릭터 꾸미기 + placeholder 렌더링
      TycoonModal.tsx
      SettingsModal.tsx         # 테마/언어/초대코드/멤버관리 등 설정 통합
      FamilySwitcher.tsx / AddFamilyModal.tsx / FamilyMembersModal.tsx
      NotificationBell.tsx / InviteQrModal.tsx / WeeklyBreakdownModal.tsx
      PhotoCropModal.tsx / InstallPromptBanner.tsx / ConfettiBurst.tsx
    styles/
      pretendard.css             # 자체 호스팅 Pretendard 가변 폰트 (@font-face, 92개 유니코드 서브셋)
      global.css                 # 팔레트(라이트/다크 + 5색 테마) + 모바일 우선 레이아웃
  public/
    icons/                       # PWA 아이콘 (192/512/apple-touch-icon)
    fonts/pretendard/            # Pretendard 서브셋 woff2 (실제 사용된 글자 범위만 다운로드됨)
  scripts/generate-icons.cjs    # 아이콘 생성 스크립트 (재실행 가능)
  .env.example
```

Supabase의 RLS/함수가 실제 규칙의 원천이고, React 쪽은 그 규칙을 호출하는 얇은 클라이언트입니다. 방
인원 제한 없음, 의뢰금/포상금 지급, 완료 기록, 게임화(레벨/골드/타이쿤/상점) 등은 모두 DB 쪽(트리거/RPC)에서
강제되며, 프런트엔드 검증은 사용자 경험을 위한 보조 수단일 뿐입니다.

---

## 1. Supabase 프로젝트 설정

> Supabase 콘솔의 메뉴 이름은 버전에 따라 바뀔 수 있습니다. 실제 콘솔에서 비슷한 이름의 메뉴를 찾아 진행하세요.

이미 만들어진 프로젝트를 사용합니다:

```
SUPABASE_URL=https://jmzucjmwgryblrpjfbzm.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_xOWGuou_lDiiVGuVFkPC3Q_gAW4-U1P
```

### 1.1 SQL 실행 (딱 한 번, 전체 파일을 위 → 아래로)

1. Supabase 콘솔 → 해당 프로젝트 → **SQL Editor** → New query
2. `supabase/schema.sql` 파일 내용을 그대로 붙여넣고 실행(Run)
   - 이 한 파일 안에 테이블 생성 → 트리거 → 함수(`create_family_room`, `join_family_room`) → RLS 정책 → 권한(GRANT) → Realtime 발행까지 순서대로 들어 있습니다.
   - 파일 맨 위 주석에 섹션별 설명이 있습니다. 재실행해도 안전하도록 `create or replace` / `drop policy if exists` 등을 사용했습니다.
3. 에러 없이 끝나면 왼쪽 **Table Editor**에서 `profiles`, `families`, `family_members`, `tasks`, `task_activities` 등 앱 전체가 쓰는 모든 테이블(게임화 관련 `shop_items`/`tycoon_state`/`member_owned_items` 등 포함, 총 17개)이 보여야 합니다.

### 1.2 Authentication 설정

Supabase 콘솔 → **Authentication** → **Providers** (또는 Settings):

- **Email** 로그인 활성화 (기본 활성화되어 있음)
- **Confirm email** (이메일 인증) 옵션
  - 가족 2명이 빠르게 테스트하려면 **꺼두는 것을 권장**합니다. 켜두면 회원가입 후 메일함의 인증 링크를 눌러야 로그인할 수 있습니다.
  - 앱 코드는 두 경우 모두 정상 동작합니다. 인증이 꺼져 있으면 가입 즉시 로그인되고, 켜져 있으면 "인증 메일을 확인해주세요" 안내가 표시됩니다.

Supabase 콘솔 → **Authentication** → **URL Configuration**:

- **Site URL**: 배포한 주소 (예: `https://your-app.vercel.app`)
- **Redirect URLs**: 아래 두 개를 모두 추가
  - `http://localhost:5173`
  - 배포 주소 (예: `https://your-app.vercel.app`)

### 1.3 Realtime

`schema.sql` 마지막 부분에서 `tasks`, `task_activities` 테이블을 `supabase_realtime` publication에 자동으로 추가합니다. 콘솔 **Database → Replication**에서 두 테이블이 켜져 있는지 확인만 하면 됩니다.

---

## 2. 로컬 설치 및 실행

```bash
cd family-quest-app
npm install
cp .env.example .env
npm run dev
```

브라우저에서 `http://localhost:5173` 접속. `.env`의 `VITE_SUPABASE_URL` / `VITE_SUPABASE_PUBLISHABLE_KEY`가 실제 Supabase 프로젝트 값과 일치해야 합니다(위 값 그대로 써도 됩니다 — publishable key는 공개되어도 안전하도록 설계된 키이며, 실제 데이터 보호는 RLS가 담당합니다. `service_role` 키는 이 프로젝트 어디에도 등장하지 않으며 절대 프런트엔드 코드/환경변수에 넣으면 안 됩니다).

### 빌드

```bash
npm run build   # tsc -b && vite build, TypeScript 오류 0개로 통과해야 함
npm run preview # 빌드 결과물을 로컬에서 미리보기
```

### 자동화 테스트 (2026-08 도입)

```bash
npm test  # vitest run -- src/**/*.test.ts
```

Supabase에 실제로 붙지 않는 순수 로직(현재는 `lib/gamification.ts`의 레벨업 계산·칭호 탭 분류)부터
시작한 첫 자동화 테스트입니다. `vite.config.ts`의 `test.env`에 가짜 Supabase URL/키를 넣어둬서,
`lib/supabaseClient.ts`를 거쳐가는(직접 API를 호출하지 않아도) 모듈을 임포트할 때 나는 "환경변수
없음" 에러를 막습니다 -- 진짜 크리덴셜이 아니니 안심하고 커밋해도 됩니다. 새 순수 함수를 추가하면
같은 패턴(`*.test.ts`, `describe`/`it`/`expect`를 `vitest`에서 직접 import)으로 테스트를 늘려가면
됩니다.

---

## 3. 배포 (Vercel 예시)

1. 이 저장소를 GitHub에 두고 [Vercel](https://vercel.com)에서 New Project → 해당 저장소 import
2. **Root Directory**를 `family-quest-app`으로 지정 (모노레포 형태이므로 반드시 지정)
3. Framework Preset: **Vite** (자동 감지됨)
4. Environment Variables에 다음 항목 추가:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`
   - `VITE_VAPID_PUBLIC_KEY` (푸시 알림 기능을 쓰려면 필요 — 아래 3-1 참고. 당장 안 쓸 거면 생략해도 앱은 정상 동작합니다)
5. Deploy
6. 배포된 주소를 Supabase **Authentication → URL Configuration**의 Site URL / Redirect URLs에 추가 (위 1.2 참고)

Netlify나 Cloudflare Pages를 쓸 경우도 동일합니다: 빌드 커맨드 `npm run build`, 출력 디렉터리 `dist`, 동일한 환경변수를 등록하면 됩니다.

### 3-2. 회사용 앱(business-quest-app) 별도 배포

2026-08부터 가족용/회사용이 완전히 분리된 두 개의 앱입니다 (`../README.md` 참고). Vercel에 **완전히 새로운 프로젝트**를 하나 더 만들어서 배포합니다 — 위 3번과 똑같이 New Project부터 다시 시작하되:

1. **같은 GitHub 저장소**를 다시 import (New Project → 이미 연결된 저장소 목록에 다시 뜸)
2. **Root Directory**를 `business-quest-app`으로 지정
3. Framework Preset: **Vite** (자동 감지됨)
4. Environment Variables — **family-quest-app과 완전히 같은 값**을 그대로 입력 (같은 Supabase 백엔드를 공유하므로):
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`
   - `VITE_VAPID_PUBLIC_KEY` (선택)
   - **`VITE_APP_MODE=business`** ← 이게 이번에 추가로 필요한 값. 안 넣으면 회사용 앱이 가족용처럼 동작합니다.
5. Deploy
6. 배포된 새 주소(family-quest-app과는 다른 도메인)를 Supabase **Authentication → URL Configuration**의 Redirect URLs에 **추가**(기존 family-quest-app 주소는 지우지 말고 같이 등록)

두 프로젝트 다 같은 저장소의 같은 브랜치를 보고 있으므로, 이후 푸시 한 번으로 두 앱이 동시에 다시 배포됩니다 — 별도로 두 번 배포할 필요 없습니다.

---

## 3-1. 푸시 알림(기한 알림) 설정

퀘스트 기한이 됐을 때 앱을 안 켜놔도 휴대폰/PC에 알림이 뜨는 기능입니다. 다른 기능들과 달리 **schema.sql만 다시 실행하는 걸로는 안 되고**, 아래 단계를 한 번 거쳐야 합니다. 전부 브라우저에서만 하는 작업이라 터미널이 없어도 됩니다 — 순서대로 하면 됩니다.

**이미 준비된 값** (이번에 새로 생성한 키 — 그대로 쓰면 됩니다):

```
VITE_VAPID_PUBLIC_KEY=BGCaf4UN5pv1R7tEtmoj4Zi8Czyalqh7IGRbyDRhWZ2HT4xB1DkmjK6oEB0YPzVgyAzwI1Am6VuDqoE766UiEsw
VAPID_PRIVATE_KEY=JuTMqywb8rLzCaeNr3Z0wFJnpWIIaSRgQOLCl4pz-E8
```

`VAPID_PRIVATE_KEY`는 **절대 .env나 프런트엔드 코드에 넣지 마세요** — Edge Function의 비밀값(secret)으로만 등록합니다. 아래 2단계에서 등록합니다.

아래는 **터미널 없이, 브라우저(Supabase 대시보드)만으로** 하는 방법입니다. 회사 컴퓨터처럼 터미널을 못 쓰는 환경에서도 그대로 따라할 수 있습니다. (나중에 집 컴퓨터 등에서 터미널을 쓸 수 있게 되면, 맨 아래 "CLI로 하는 방법"으로 대체해도 됩니다 — 결과는 동일합니다.)

### 3-1-0. schema.sql 다시 실행 (최초 1회, 잊지 마세요)

이 기능은 `push_subscriptions` 테이블과 `tasks.due_reminder_sent_for` 컬럼을 새로 추가합니다. Supabase **SQL Editor**에서 저장소의 `family-quest-app/supabase/schema.sql` 전체 내용을 복사해서 다시 실행하세요 (위 1.1과 동일한 방법). 이걸 건너뛰면 아래 단계에서 `relation "push_subscriptions" does not exist` 같은 오류가 납니다.

### 3-1-1. Edge Function 만들기 (브라우저에서, 최초 1회)

1. [supabase.com](https://supabase.com) 접속 → 로그인 → 이 프로젝트 선택
2. 왼쪽 메뉴에서 **Edge Functions** 클릭
3. **Deploy a new function** (또는 "Create a new function") 클릭 → **Via Editor**(코드 편집기로 직접 작성) 선택 — CLI 관련 옵션이 아니라 브라우저에서 코드를 붙여넣는 방식입니다
4. 함수 이름(Name/Slug)에 정확히 `send-due-reminders` 입력 (이 이름이어야 아래 SQL과 일치합니다)
5. 편집기에 기본으로 채워진 코드를 전부 지우고, 이 저장소의 `family-quest-app/supabase/functions/send-due-reminders/index.ts` 파일 내용을 그대로 복사해서 붙여넣기 (GitHub에서 해당 파일 열기 → 우측 복사 아이콘)
6. **Deploy** 클릭

**이후 코드가 바뀔 때마다**(예: 이번에 담당 배정/완료/댓글 알림이 추가된 것처럼): 새 함수를 또 만들 필요 없이, 기존 함수 페이지의 **Code** 탭에서 내용을 최신 버전으로 바꿔 넣고 다시 **Deploy**만 누르면 됩니다. 시크릿/JWT 설정은 그대로 유지됩니다. (참고: 이 프로젝트는 처음 만들 때 실수로 실제 함수 이름이 `send-due-reminders`가 아니라 `rapid-service`로 배포되어 있습니다 — Supabase는 함수 이름을 나중에 못 바꾸기 때문에 그대로 쓰고 있고, `schema.sql`의 관련 URL들도 전부 `rapid-service` 기준으로 맞춰뒀습니다.)

### 3-1-2. Edge Function 비밀값(Secrets) 등록 (최초 1회)

Edge Functions 페이지에서 방금 만든 `send-due-reminders` 함수로 들어가면 **Secrets**(비밀값) 관리 메뉴가 있습니다 (프로젝트 전체 공통 설정이라 "Manage secrets" 같은 이름으로 별도 페이지에 있을 수도 있습니다 — Edge Functions 섹션 안에서 찾으면 됩니다). 아래 3개를 추가하세요:

| Key | Value |
|---|---|
| `VAPID_PUBLIC_KEY` | `BGCaf4UN5pv1R7tEtmoj4Zi8Czyalqh7IGRbyDRhWZ2HT4xB1DkmjK6oEB0YPzVgyAzwI1Am6VuDqoE766UiEsw` |
| `VAPID_PRIVATE_KEY` | `JuTMqywb8rLzCaeNr3Z0wFJnpWIIaSRgQOLCl4pz-E8` |
| `VAPID_SUBJECT` | `mailto:본인이메일@example.com` (실제 이메일 주소로) |

`VAPID_PRIVATE_KEY`는 여기(Secrets)에만 등록하고 **.env나 Vercel 등 프런트엔드 쪽에는 절대 넣지 마세요**. `SUPABASE_URL`/`SUPABASE_SERVICE_ROLE_KEY`는 Edge Function에 자동으로 주입되므로 따로 등록할 필요 없습니다. 저장 후 함수가 자동으로 다시 배포되지 않는다면 Edge Functions 페이지에서 **Redeploy**를 한 번 눌러주세요 (비밀값은 재배포 시점부터 적용됩니다).

### 3-1-3. 스케줄러(pg_cron) 켜기 (최초 1회)

Supabase 대시보드 **SQL Editor**에서 아래를 실행합니다 (`schema.sql`의 섹션 13 하단에 있는 것과 같은 내용이며, 이 프로젝트 값으로 미리 채워뒀습니다):

```sql
select cron.schedule(
  'send-due-reminders',
  '* * * * *',
  $$
  select net.http_post(
    url := 'https://jmzucjmwgryblrpjfbzm.supabase.co/functions/v1/rapid-service',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer sb_publishable_xOWGuou_lDiiVGuVFkPC3Q_gAW4-U1P'
    ),
    body := '{}'::jsonb
  );
  $$
);
```

(`schema.sql`을 처음부터 다시 실행할 때 `pg_cron`/`pg_net` extension은 함께 켜지지만, 이 `cron.schedule` 호출 자체는 프로젝트별 URL이 필요해서 일부러 주석 처리되어 있습니다 — 이 블록만 따로 한 번 실행하면 됩니다.)

**`ERROR: schema "cron" does not exist`가 뜬다면**: `pg_cron` extension이 아직 안 켜진 것입니다. 위 3-1-0에서 `schema.sql`을 다시 실행했는데도 이 오류가 나면, SQL로 켜는 대신 대시보드에서 직접 켜세요 — 왼쪽 메뉴 **Database → Extensions** → 검색창에 `pg_cron` 입력 → 토글로 활성화 (`pg_net`도 같은 방법으로 활성화). 이후 위 `cron.schedule(...)` 블록을 다시 실행하면 됩니다.

**마감 초과(에스컬레이션) 알림**은 별도 스케줄 없이 위 `send-due-reminders` 크론(매분 실행)에 얹혀서 함께 처리됩니다 — 추가 설정 불필요.

**주간 리포트 알림**(매주 월요일 오전 9시)은 별도 스케줄이 하나 더 필요합니다. 위와 같은 SQL Editor에서 아래를 한 번 더 실행하세요:

```sql
select cron.schedule(
  'send-weekly-summary',
  '0 0 * * 1',
  $$
  select net.http_post(
    url := 'https://jmzucjmwgryblrpjfbzm.supabase.co/functions/v1/rapid-service',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer sb_publishable_xOWGuou_lDiiVGuVFkPC3Q_gAW4-U1P'
    ),
    body := '{"weekly_summary": true}'::jsonb
  );
  $$
);
```

**회원 탈퇴(계정 삭제) 처리**는 매일 새벽 한 번, 7일 유예기간이 지난 탈퇴 신청을 실제로 처리합니다(로그인 영구 차단 + 개인정보 익명화 — `schema.sql` 섹션 43 참고). 이 기능을 쓰려면:

1. 위 3-1-1의 **Code** 탭에서, 이 저장소의 최신 `send-due-reminders/index.ts` 내용으로 갱신하고 **Deploy** (새 함수를 만들 필요 없음 — 같은 함수에 경로 하나가 추가된 것뿐입니다)
2. `schema.sql`을 다시 실행 (섹션 43이 새로 추가됨 — 재실행 안전)
3. 아래를 SQL Editor에서 한 번 실행:

```sql
select cron.schedule(
  'process-account-deletions',
  '30 16 * * *',
  $$
  select net.http_post(
    url := 'https://jmzucjmwgryblrpjfbzm.supabase.co/functions/v1/rapid-service',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer sb_publishable_xOWGuou_lDiiVGuVFkPC3Q_gAW4-U1P'
    ),
    body := '{"process_account_deletions": true}'::jsonb
  );
  $$
);
```

이 크론이 없어도 회원 탈퇴 신청/취소 자체(설정 화면)는 정상 동작합니다 — 다만 7일 뒤 실제 처리(로그인 차단·정보 익명화)가 이 스케줄러 없이는 일어나지 않습니다.

### 3-1-4. Vercel 환경변수 추가

위 3단계 "배포 (Vercel 예시)"에서 `VITE_VAPID_PUBLIC_KEY`를 추가하지 않았다면 Vercel 프로젝트 설정 → Environment Variables에 추가 후 **Redeploy**.

### 3-1-5. 켜서 확인하기

1. 배포된 사이트에 접속 → 우측 상단 🔔 알림 아이콘 클릭
2. "기한 알림 (기기 알림)" 토글을 켜면 브라우저가 알림 권한을 물어봄 → 허용
3. 테스트: 새 퀘스트를 만들면서 기한을 "지금부터 2분 뒤"로 설정 → 앱을 최소화하거나 다른 탭으로 이동 → 2분 이내(최대 1분 간격으로 검사하므로 최대 약 3분)에 기기 알림이 뜨는지 확인

**참고**: 크롬/엣지(안드로이드, 데스크톱)는 잘 지원됩니다. iPhone Safari는 iOS 16.4+이고 **홈 화면에 추가한 앱**으로 실행 중일 때만 지원됩니다(사파리 브라우저 탭에서는 동작하지 않음) — 위 4번 "홈 화면 설치"를 먼저 해야 합니다.

### 참고: 나중에 터미널을 쓸 수 있을 때 (CLI 방법)

3-1-1, 3-1-2를 대시보드 대신 터미널로 하고 싶다면:

```bash
npm install -g supabase
supabase login
cd family-quest-app
supabase link --project-ref jmzucjmwgryblrpjfbzm
supabase secrets set VAPID_PUBLIC_KEY=BGCaf4UN5pv1R7tEtmoj4Zi8Czyalqh7IGRbyDRhWZ2HT4xB1DkmjK6oEB0YPzVgyAzwI1Am6VuDqoE766UiEsw
supabase secrets set VAPID_PRIVATE_KEY=JuTMqywb8rLzCaeNr3Z0wFJnpWIIaSRgQOLCl4pz-E8
supabase secrets set VAPID_SUBJECT=mailto:본인이메일@example.com
supabase functions deploy send-due-reminders
```

코드를 나중에 수정하게 되면(지금은 수정할 필요 없음) `supabase functions deploy send-due-reminders`만 다시 실행하면 됩니다. 3-1-3(pg_cron), 3-1-4(Vercel)는 CLI를 쓰든 대시보드를 쓰든 동일합니다.

---

## 3-2. Capacitor(광고/인앱결제) 설정

`MONETIZATION_DESIGN.md` 섹션 1(광고 기반 무료 + 방 단위 광고 제거)을 실제로 동작시키려면
필요한 단계입니다. 코드/스캐폴드는 이미 다 되어 있고(`android/` 디렉터리, `lib/ads.ts`,
`lib/purchases.ts`, Edge Function의 RevenueCat 웹훅 경로), **이 앱에서 대신 만들어줄 수
없는 외부 계정 3개**를 만들고 아래 값들을 채워 넣어야 실제로 광고가 뜨고 결제가 됩니다.
이 샌드박스엔 Android SDK/에뮬레이터가 없어서 실제 빌드·기기 테스트는 이 저장소를 로컬(또는
Android Studio가 있는 환경)에 내려받아서 진행해야 합니다.

### 3-2-1. Google Play Console

1. 앱 등록 (패키지명은 `capacitor.config.ts`의 `appId`와 반드시 동일하게 --
   `com.howlingcreative.familyquest`. **한 번 배포하면 바꿀 수 없으니** 다른 이름을
   쓰고 싶으면 배포 전에 지금 바꿔야 함)
2. **인앱상품(관리형, 비소모성)** 하나 등록 -- 상품 ID는 자유(예: `remove_ads`), 가격
   300엔 근처로 설정

### 3-2-2. RevenueCat

1. [revenuecat.com](https://www.revenuecat.com)에서 프로젝트 생성, 위 Play Console 앱과 연결
2. 3-2-1에서 만든 상품을 RevenueCat의 **Product**로 가져오고, **Lifetime 타입 Package**로
   Offering(Current로 지정)에 담기 -- `lib/purchases.ts`가 `packageType === LIFETIME`인
   패키지를 찾아서 구매를 시작하므로, 반드시 Lifetime 타입으로 등록해야 함
3. **Webhook** 설정 (RevenueCat 대시보드 > Integrations > Webhooks):
   - URL: 이 프로젝트의 `rapid-service` Edge Function URL (3-1-1에서 만든 것과 동일,
     `https://jmzucjmwgryblrpjfbzm.supabase.co/functions/v1/rapid-service`)
   - Authorization 헤더: 3-1-3의 크론들과 동일한 publishable key 값 (`Bearer sb_publishable_xOWGuou_lDiiVGuVFkPC3Q_gAW4-U1P`) --
     이 함수의 "Verify JWT" 설정을 그대로 통과시키기 위한 것으로, 별도 시크릿 관리가 필요 없음
4. 공개 Android SDK 키를 복사해서 `src/lib/purchases.ts`의
   `REVENUECAT_ANDROID_API_KEY` 자리에 붙여넣기

### 3-2-3. AdMob

1. [admob.google.com](https://admob.google.com)에서 앱 등록, **배너 광고 단위** 하나 생성
2. 발급된 **App ID**를 `android/app/src/main/res/values/strings.xml`의 `admob_app_id`에
   교체 (지금은 Google 공식 테스트용 App ID가 들어있어서 항상 테스트 광고만 나옴)
3. 발급된 **광고 단위 ID**를 `src/lib/ads.ts`의 `BANNER_AD_UNIT_ID`에 교체

### 3-2-4. 빌드/동기화

```bash
cd family-quest-app
npm run cap:sync        # 웹 빌드 + android/ 프로젝트에 최신 웹 자산·플러그인 동기화
npm run cap:open:android # Android Studio에서 android/ 열기 (Android Studio 필요)
```

Android Studio에서 실제 기기/에뮬레이터로 실행해서 배너 광고와 "광고 제거" 구매(설정 화면)가
정상 동작하는지 확인 -- 이 부분은 이 샌드박스에서 검증 불가능했던 부분이라 실제 확인이
필요합니다.

---

## 3-3. FCM(네이티브 푸시 알림) 설정 -- 스토어에 내려면 필수

**왜 필요한가**: 지금까지의 마감/댓글/주간 리포트 알림은 전부 "Web Push"(브라우저 표준)
방식인데, 이건 **안드로이드 WebView에서 아예 지원되지 않습니다** (백그라운드 실행 자체가
안 됨, 네이티브 알림 권한 요청창도 안 뜸). Capacitor로 감싼 이 앱은 WebView로 화면을
그리기 때문에, Play Store에서 설치한 앱에서는 Web Push가 작동하지 않습니다. 이 문제를
풀려면 안드로이드 앱의 표준 푸시 방식인 **FCM(Firebase Cloud Messaging)**을 별도로
붙여야 합니다 (코드는 이미 다 되어 있음 -- `lib/nativePush.ts`,
`supabase/functions/send-due-reminders/index.ts`의 `sendFcmMessage`,
`schema.sql` 섹션 45). FCM 자체는 완전 무료(메시지 건수 제한 없음)입니다.

### 3-3-1. Firebase 프로젝트 만들기

1. [console.firebase.google.com](https://console.firebase.google.com)에서 새 프로젝트 생성
2. **Android 앱 추가** -- 패키지명은 정확히 `com.howlingcreative.familyquest`
3. 이 화면에서 **`google-services.json`** 파일을 다운로드 → `family-quest-app/android/app/` 디렉터리에 그대로 넣기
   (이 파일이 있어야 안드로이드 빌드가 자동으로 Firebase를 연결함 -- 없으면 빌드는 되지만
   "Push Notifications won't work"라는 로그만 남기고 조용히 비활성화됨)

### 3-3-2. 서비스 계정 키 발급 (Edge Function이 FCM으로 발송하려면 필요)

1. Firebase 콘솔 > 프로젝트 설정(⚙️) > **서비스 계정** 탭
2. **새 비공개 키 생성** 클릭 → JSON 파일 다운로드
3. 이 JSON 파일의 **전체 내용**을 그대로 복사

### 3-3-3. Edge Function Secrets에 등록 (3-1-2와 같은 화면)

| Key | Value |
|---|---|
| `FCM_SERVICE_ACCOUNT_JSON` | 3-3-2에서 받은 JSON 파일 내용 전체 (한 줄로) |
| `FCM_PROJECT_ID` | Firebase 프로젝트 ID (프로젝트 설정 화면 상단에 있음) |

등록 후 Edge Function **Redeploy** (이 저장소의 최신 `send-due-reminders/index.ts` 코드로
갱신하는 것도 잊지 말 것 -- FCM 발송 로직이 새로 추가되어 있음).

### 3-3-4. schema.sql 다시 실행

섹션 45(`native_push_tokens` 테이블)가 추가되어 있으니, 3-1-0처럼 `schema.sql` 전체를
SQL Editor에서 다시 실행 (재실행 안전).

### 3-3-5. 확인

Android Studio에서 실기기/에뮬레이터로 실행 → 알림 벨의 푸시 토글을 켜서 권한을 허용하고,
마감 임박 퀘스트를 만들어서 실제로 알림이 오는지 확인. 이것도 이 샌드박스에선 검증
불가능했던 부분입니다.

---

## 4. Android / iPhone 홈 화면 설치

### Android (Chrome)

1. 배포된 주소를 Chrome으로 접속
2. 우측 상단 메뉴(⋮) → **홈 화면에 추가** (또는 자동으로 뜨는 설치 배너의 "설치" 버튼)
3. 홈 화면 아이콘으로 실행하면 주소창 없는 전체 화면 앱으로 열림

### iPhone (Safari)

1. 배포된 주소를 Safari로 접속 (다른 브라우저에서는 홈 화면 추가가 동작하지 않을 수 있음)
2. 하단 공유 버튼(□↑) → **홈 화면에 추가**
3. 홈 화면 아이콘으로 실행

두 경우 모두 로그인 세션은 유지되며(Supabase 세션이 로컬에 저장됨), 앱을 껐다 켜도 다시 로그인할 필요가 없습니다.

---

## 5. 테스트 계정 2개로 점검하는 절차

계정 A, B 두 개의 서로 다른 이메일을 준비합니다 (실제 메일함에 접근 가능한 주소 권장; 이메일 인증을 꺼두었다면 아무 이메일이나 사용 가능).

### 사용자 A

1. 회원가입 탭에서 표시 이름 / 이메일 / 비밀번호 입력 → 가입
2. (이메일 인증이 켜져 있다면 메일 확인 후) 로그인
3. 방 만들기 화면에서 방 이름 입력 → 종류(가족방/개인방/회사방) 선택 → **방 만들기**
4. 대시보드 상단에서 8자리 초대 코드 확인 (탭하면 복사됨)
5. **퀘스트 전달** → 제목/설명 입력
6. B가 참여한 뒤, 새 퀘스트를 하나 더 만들며 담당자로 **B**를 지정

### 사용자 B

1. 다른 브라우저(또는 시크릿 창)에서 별도 이메일로 회원가입 → 로그인
2. 방 참여하기 화면에서 A가 준 8자리 코드 입력 → **참여하기**
3. 대시보드에서 A가 만든 퀘스트가 보이는지 확인
4. 담당자로 지정된 퀘스트를 열어 **처리 결과**를 입력하고 **완료하기**

### 사용자 A 재확인

1. 대시보드에서 새로고침(또는 실시간 반영)으로 해당 퀘스트가 "완료"로 바뀌었는지 확인
2. 퀘스트 상세에서 처리 결과 메모 확인
3. 하단 **처리 기록**에서 등록/완료 내역이 시간순으로 보이는지 확인
4. **다시 진행하기**를 눌러 상태가 "진행 중"으로 돌아가는지 확인 (처리 기록에 "다시 진행" 항목이 추가됨)

### 언어 테스트

1. A는 한국어 그대로 사용, B는 로그인 후 언어 전환 버튼으로 일본어로 전환
2. 같은 퀘스트 데이터가 각자 화면에서 선택한 언어(한국어/일본어)로 보이는지 확인
3. B가 언어를 다시 바꾸거나 재로그인해도 이전에 만든 퀘스트 데이터가 그대로 유지되는지 확인 (언어는 표시만 바뀌고 데이터는 별개)

### 기기 테스트

- 안드로이드 Chrome에서 위 시나리오 진행 + 홈 화면 설치
- 아이폰 Safari에서 위 시나리오 진행 + 홈 화면 추가
- 로그인 상태 유지, 날짜/시간 입력창(`datetime-local`), 완료 결과 textarea 등이 각 기기에서 정상 동작하는지 확인

---

## 6. 보안(RLS) 테스트 절차

목표: **Publishable Key가 공개되어도, 다른 가족방의 데이터는 절대 조회/수정할 수 없어야 한다.**

1. 서로 다른 가족방에 속한 두 계정을 준비 (계정 A/B가 한 가족방, 계정 C는 다른 가족방 또는 아직 가족방 없음)
2. 계정 A로 로그인한 브라우저에서 개발자 도구(Console) 열기
3. Network 탭에서 앱이 이미 보낸 PostgREST 요청(`GET .../rest/v1/tasks?...` 등) 하나를 우클릭 → Copy as fetch로 복사한 뒤, 쿼리스트링의 `family_id` 값을 다른(존재하지만 내가 속하지 않은) 가족방의 UUID로 바꿔서 콘솔에 붙여넣고 실행
4. 기대 결과: `tasks`, `family_members`, `families`, `task_activities` 조회 결과가 **빈 배열**로 와야 합니다 (에러가 아니라 "0건"으로 필터링되는 것이 RLS의 정상 동작입니다)
5. 같은 방식으로 다른 가족방의 `task_id`를 골라 `PATCH`(완료 처리, 담당자 변경 등)를 시도 → 영향받은 행이 0건이어야 합니다 (역시 에러가 아니라 "아무 것도 바뀌지 않음"이 정상)
6. `family_members`에 자신을 다른 가족방 멤버로 직접 `POST`(insert)해보기 → 실패해야 합니다 (해당 테이블에는 insert 정책 자체가 없고, 참여는 `join_family_room` RPC로만 가능)
7. 이미 속한 가족방의 초대 코드로 같은 계정이 다시 `join_family_room` 호출 → `already_in_this_family` 오류가 나야 합니다 (한 계정이 여러 가족방에 속하는 것 자체는 정상 동작이므로, "이미 어딘가에 속해 있다"가 아니라 "이 가족방에는 이미 속해 있다"만 막습니다)
8. 다른 계정의 `family_members` 행에서 `display_name`이 아닌 다른 컬럼(`role` 등)을 `PATCH`로 바꿔보기 → 실패해야 합니다 (컬럼 단위 권한으로 `display_name`만 허용되고, 그마저도 본인 행만 가능)

이 저장소의 `supabase/schema.sql`에서 위 동작을 보장하는 부분:

- 모든 테이블 `enable row level security` (섹션 9)
- `families` / `family_members`는 **insert 정책이 아예 없음** → 클라이언트가 직접 넣을 방법이 없고, 오직 `create_family_room` / `join_family_room` (SECURITY DEFINER) 함수만 삽입 가능
- `is_family_member()` / `shares_family_with()` 헬퍼 함수가 SECURITY DEFINER로 재귀 없이 멤버십을 확인 (섹션 5) — `family_members` 자기 자신을 참조하는 정책에서 무한 재귀가 나지 않도록 설계
- `family_members`의 update 정책은 본인 행으로 제한되고, 컬럼 단위 권한(`grant update (display_name)`)으로 `display_name` 외 컬럼은 애초에 클라이언트가 바꿀 방법이 없음 (섹션 10/11)
- 가족방 인원수 제한은 없음 (예전 2명 제한 트리거는 제거됨) — 대신 `already_in_this_family` 체크로 같은 가족방에 중복 참여만 막음

---

## 7. 아직 없는 기능

음성 입력, 관리자(운영자) 페이지, 앱스토어/플레이스토어 정식 등록, 완전한 오프라인 모드(네트워크 큐잉·충돌 병합 등). 그 외 v0.1 시점에 없었던 포인트/레벨/게임화 전반, 3인 이상 방, 개인방·회사방 종류, 다국어(한국어/일본어), 푸시 알림 등은 이후 단계적으로 구현되어 이미 기본 기능에 포함되어 있습니다 — 자세한 구현 이력은 `GAMIFICATION_DESIGN.md` 참고.

## 8. 알려진 제약

- 실제 Supabase 프로젝트 설정(1장)·배포(3장)·푸시 알림 설정(3-1장)·계정 2개 실사용 테스트(5장)·RLS 보안 테스트(6장)는 모두 완료되어, 지금은 실제 배포된 앱을 가족이 일상적으로 쓰면서 나오는 피드백을 바탕으로 계속 수정·기능 추가가 이루어지는 단계입니다. 다만 이 코드 작업을 하는 개발 환경 자체는 외부 네트워크가 제한되어 있어, AI가 직접 그 Supabase 프로젝트나 배포된 사이트에 접속해 확인하지는 못합니다 — `supabase/schema.sql` 변경 사항은 로컬 Postgres 16 인스턴스에 적용해 함수/트리거/정책 동작을 검증하고, UI 변경은 정적 렌더링(Playwright)으로 검증한 뒤, 실제 반영 여부는 사용자 피드백(스크린샷 등)으로 확인하는 방식으로 진행합니다.
- 오프라인 모드는 지원하지 않습니다. 네트워크가 끊기면 각 화면에서 요청 실패가 노출됩니다(무한 로딩으로 멈추지 않음).
